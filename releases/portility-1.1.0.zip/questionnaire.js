/**
 * questionnaire.js
 * Portility — Questionnaire logic and answer-to-instruction mapping.
 *
 * Generates a markdown instruction packet from questionnaire answers.
 */

'use strict';

/**
 * Generate operating instructions text from questionnaire answers.
 * @param {Object} answers
 * @returns {string}
 */
function generateInstructions(answers) {
  var instructions = [];

  // Communication Style (multi-select — array or legacy string)
  var commStyle = answers.communicationStyle;
  // Backward compat: wrap string in array
  if (typeof commStyle === 'string' && commStyle) { commStyle = [commStyle]; }
  if (Array.isArray(commStyle) && commStyle.length > 0) {
    var commMap = {
      'direct': 'Keep responses concise and to the point.',
      'detailed': 'Provide thorough, detailed explanations.',
      'conversational': 'Use a warm, conversational tone.',
      // Legacy values
      'short-direct': 'Deliver information concisely. Provide detail only when explicitly requested.',
      'bullets': 'Organize information with bullet points and clear sections.',
      'full': 'Provide comprehensive explanations with full context.',
      'mix': 'Adapt communication style to the context. Default to concise, expand when needed.',
    };
    var commParts = [];
    for (var i = 0; i < commStyle.length; i++) {
      if (commStyle[i] === 'other' && answers.communicationStyle_customText) {
        commParts.push(answers.communicationStyle_customText.trim());
      } else if (commMap[commStyle[i]]) {
        commParts.push(commMap[commStyle[i]]);
      }
    }
    if (commParts.length > 0) {
      instructions.push(commParts.join(' '));
    }
  }

  // What Not To Do (multi-select — array or legacy string)
  var notToDo = answers.whatNotToDo;
  // Backward compat: wrap string in array
  if (typeof notToDo === 'string' && notToDo) { notToDo = [notToDo]; }
  if (Array.isArray(notToDo) && notToDo.length > 0) {
    var notMap = {
      'elaborate': "Don't elaborate on my ideas without being asked.",
      'assumptions': "Don't make assumptions about what I mean.",
      'clarifying': "Don't ask clarifying questions before answering \u2014 just answer.",
      'formal': "Don't be overly formal or robotic.",
      'interrupts': "Don't interrupt my train of thought.",
      // Legacy values
      'custom_text': null, // handled via customText below
    };
    var notParts = [];
    for (var j = 0; j < notToDo.length; j++) {
      if ((notToDo[j] === 'other' || notToDo[j] === 'custom_text') && answers.whatNotToDo_customText) {
        notParts.push(answers.whatNotToDo_customText.trim());
      } else if (notMap[notToDo[j]]) {
        notParts.push(notMap[notToDo[j]]);
      }
    }
    if (notParts.length > 0) {
      instructions.push(notParts.join(' '));
    }
  }

  // Confidentiality
  if (answers.confidentiality === 'private') {
    instructions.push("I'm working on confidential projects. Never reference my work, ideas, or concepts in other conversations or contexts. Keep all confidential material isolated and private.");
  } else if (answers.confidentiality === 'contexts') {
    instructions.push('Some of my work is confidential. Ask me to clarify which topics are private before discussing them in other contexts.');
  }
  // "none" — no instruction added

  // Multimodal
  if (answers.multimodal === 'text') {
    instructions.push('Expect text-based input. Respond in clear, written text format.');
  } else if (answers.multimodal === 'voice') {
    instructions.push('I often dictate. Be prepared for voice input and respond in a format suitable for reading aloud or transcription.');
  } else if (answers.multimodal === 'documents') {
    instructions.push('I frequently upload files, documents, and images. Be prepared to analyze and respond to visual and document-based input.');
  } else if (answers.multimodal === 'all') {
    instructions.push('I work multimodally \u2014 I may dictate, paste text, upload documents, or send images. Be prepared to handle any input format. Also be ready to output in any format I request: text, voice transcripts, structured documents, images, or visual presentations.');
  }

  // Other Preferences
  if (answers.otherPreferences && answers.otherPreferences.trim()) {
    instructions.push('Additional instruction: ' + answers.otherPreferences.trim());
  }

  return instructions.join('\n\n');
}

/**
 * Build the full instruction packet with a header.
 * @param {Object} answers
 * @returns {string}
 */
function buildInstructionPacket(answers) {
  var header = '# My Operating Instructions\n\nThese are my standing instructions for how I like to work with AI. Please follow them throughout our conversation.\n\n---\n\n';
  var body = generateInstructions(answers);
  return header + body;
}
