/**
 * oauth.js
 * Portility — Google OAuth via chrome.identity.launchWebAuthFlow.
 *
 * Uses launchWebAuthFlow for reliable auth in both unpacked and published extensions.
 */

'use strict';

// OAuth Client ID — must be a "Web application" type credential
// with redirect URI: https://<extension-id>.chromiumapp.org/
var OAUTH_CLIENT_ID = '542250387353-k1uu29l3844ct0404i83nboe011btbvc.apps.googleusercontent.com';

/**
 * Get a Google OAuth access token using launchWebAuthFlow.
 * @param {boolean} interactive - Whether to show login UI
 * @returns {Promise<string>} Access token
 */
async function getGoogleAccessToken(interactive) {
  if (interactive === undefined) interactive = true;

  // Check for cached token first
  var cached = await new Promise(function (resolve) {
    chrome.storage.local.get('google_access_token', function (data) {
      resolve(data.google_access_token || null);
    });
  });

  if (cached) {
    // Verify token is still valid
    try {
      var resp = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
        headers: { 'Authorization': 'Bearer ' + cached },
      });
      if (resp.ok) return cached;
    } catch (e) {}
    // Token invalid — clear and re-auth
    await new Promise(function (resolve) {
      chrome.storage.local.remove('google_access_token', resolve);
    });
  }

  if (!interactive) {
    throw new Error('No valid token and interactive auth not allowed');
  }

  var redirectUrl = chrome.identity.getRedirectURL();
  var scopes = encodeURIComponent('profile https://www.googleapis.com/auth/datastore');
  var authUrl = 'https://accounts.google.com/o/oauth2/v2/auth' +
    '?client_id=' + encodeURIComponent(OAUTH_CLIENT_ID) +
    '&response_type=token' +
    '&redirect_uri=' + encodeURIComponent(redirectUrl) +
    '&scope=' + scopes +
    '&prompt=consent';

  return new Promise(function (resolve, reject) {
    chrome.identity.launchWebAuthFlow(
      { url: authUrl, interactive: true },
      function (responseUrl) {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        if (!responseUrl) {
          reject(new Error('No response from auth flow'));
          return;
        }
        // Extract access token from redirect URL hash
        var match = responseUrl.match(/access_token=([^&]*)/);
        if (match && match[1]) {
          var token = match[1];
          // Cache the token
          chrome.storage.local.set({ google_access_token: token });
          resolve(token);
        } else {
          reject(new Error('No access token in auth response'));
        }
      }
    );
  });
}

/**
 * Get the Google user's profile info (to extract user ID).
 * @param {string} accessToken
 * @returns {Promise<{id: string, email: string, name: string}>}
 */
async function getGoogleUserInfo(accessToken) {
  var response = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
    headers: { 'Authorization': 'Bearer ' + accessToken },
  });

  if (!response.ok) {
    if (response.status === 401) {
      // Clear cached token
      await new Promise(function (resolve) {
        chrome.storage.local.remove('google_access_token', resolve);
      });
      throw new Error('Token expired. Please try again.');
    }
    throw new Error('Failed to fetch user info');
  }

  return response.json();
}

/**
 * Get the stored Google user ID, or fetch and store it.
 * @returns {Promise<string>}
 */
async function getGoogleUserId() {
  var cached = await new Promise(function (resolve) {
    chrome.storage.local.get('google_user_id', function (data) {
      resolve(data.google_user_id || null);
    });
  });

  if (cached) return cached;

  var token = await getGoogleAccessToken(false);
  var userInfo = await getGoogleUserInfo(token);

  await new Promise(function (resolve) {
    chrome.storage.local.set({ google_user_id: userInfo.id }, resolve);
  });

  return userInfo.id;
}

/**
 * Ensure user is authenticated. Returns { token, userId }.
 * Triggers interactive login if needed.
 * @returns {Promise<{token: string, userId: string}>}
 */
async function ensureAuthenticated() {
  var token = await getGoogleAccessToken(true);
  var userInfo = await getGoogleUserInfo(token);

  await new Promise(function (resolve) {
    chrome.storage.local.set({ google_user_id: userInfo.id }, resolve);
  });

  return { token: token, userId: userInfo.id };
}
