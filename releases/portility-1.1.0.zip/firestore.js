/**
 * firestore.js
 * Portility — Firestore REST API operations for operating instructions.
 *
 * Stores encrypted instruction blobs in Firestore, keyed by Google user ID.
 * All encryption/decryption happens client-side before data touches the network.
 */

'use strict';

// TODO: Replace with your actual Google Cloud project ID
var FIRESTORE_PROJECT_ID = 'portility';

/**
 * Save encrypted instructions to Firestore.
 * @param {string} instructionsText - Plain text instructions (will be encrypted)
 * @param {string} passphrase
 * @param {string} accessToken - Google OAuth token
 * @param {string} userId - Google user ID (Firestore document ID)
 * @param {Object} answers - Raw questionnaire answers (stored encrypted alongside instructions)
 * @returns {Promise<void>}
 */
async function saveInstructionsToFirestore(instructionsText, passphrase, accessToken, userId, answers) {
  var encryptedResult = await encryptInstructions(instructionsText, passphrase);

  var url = 'https://firestore.googleapis.com/v1/projects/' + FIRESTORE_PROJECT_ID +
    '/databases/(default)/documents/user_operating_instructions/' + userId;

  var now = new Date().toISOString();

  var response = await fetch(url, {
    method: 'PATCH',
    headers: {
      'Authorization': 'Bearer ' + accessToken,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      fields: {
        userId: { stringValue: userId },
        encryptedInstructions: { stringValue: encryptedResult.encrypted },
        salt: { stringValue: encryptedResult.salt },
        iv: { stringValue: encryptedResult.iv },
        answers: { stringValue: JSON.stringify(answers) },
        createdAt: { timestampValue: now },
        lastUpdated: { timestampValue: now },
        questionnaiireCompleted: { booleanValue: true },
      },
    }),
  });

  if (!response.ok) {
    var err = await response.json().catch(function () { return {}; });
    throw new Error(err.error?.message || 'Failed to save to Firestore');
  }
}

/**
 * Retrieve encrypted instructions from Firestore.
 * @param {string} accessToken - Google OAuth token
 * @param {string} userId - Google user ID
 * @returns {Promise<{encrypted: string, salt: string, iv: string, answers: Object|null, questionnaiireCompleted: boolean}|null>}
 */
async function getInstructionsFromFirestore(accessToken, userId) {
  var url = 'https://firestore.googleapis.com/v1/projects/' + FIRESTORE_PROJECT_ID +
    '/databases/(default)/documents/user_operating_instructions/' + userId;

  var response = await fetch(url, {
    headers: { 'Authorization': 'Bearer ' + accessToken },
  });

  if (response.status === 404) return null;

  if (!response.ok) {
    throw new Error('Failed to retrieve instructions from Firestore');
  }

  var doc = await response.json();
  if (!doc.fields) return null;

  var result = {
    encrypted: doc.fields.encryptedInstructions?.stringValue || '',
    salt: doc.fields.salt?.stringValue || '',
    iv: doc.fields.iv?.stringValue || '',
    answers: null,
    questionnaiireCompleted: doc.fields.questionnaiireCompleted?.booleanValue || false,
  };

  if (doc.fields.answers?.stringValue) {
    try {
      result.answers = JSON.parse(doc.fields.answers.stringValue);
    } catch (e) {
      result.answers = null;
    }
  }

  return result;
}

/**
 * Check if questionnaire has been completed (via Firestore).
 * Falls back gracefully if network or auth fails.
 * @param {string} accessToken
 * @param {string} userId
 * @returns {Promise<boolean>}
 */
async function checkQuestionnaireCompletedRemote(accessToken, userId) {
  try {
    var data = await getInstructionsFromFirestore(accessToken, userId);
    return data ? data.questionnaiireCompleted : false;
  } catch (e) {
    return false;
  }
}
