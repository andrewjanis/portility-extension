/**
 * popup.js
 * Portility — extension popup.
 *
 * Handles:
 *   - Operating Instructions questionnaire (onboarding flow)
 *   - Port Me: decrypt instructions from Firestore, pick destination, copy + open tab
 *   - Port My Chat: extract conversation from page, pick destination, copy + open tab
 *   - Edit Instructions: re-run questionnaire with pre-filled answers
 *   - Save as .txt: downloads content as a text file
 *   - Request a Feature: opens Google Form in new tab
 *   - Bug Report: collects metadata + optional note, sends to PostHog
 *   - Error capture: silently collects JS errors during popup session
 */

'use strict';

// ─── Config ───────────────────────────────────────────────────────────────────
const POSTHOG_API_KEY = 'phc_Am8QxJfBbaSQVfEbANuaPVWWfeEWoKQEqK7QKo38Y9fD';
const POSTHOG_HOST = 'https://app.posthog.com';
// PROXY_URL, GOOGLE_SHEET_WEBHOOK are loaded from config.js (via script tag in popup.html)
const FEATURE_REQUEST_URL = 'https://docs.google.com/forms/d/e/1FAIpQLSeCMXd1I6-I0G0y3rl5C8a0Cl2qlrVXuwjtpa138eeaEnq_OQ/viewform?usp=dialog';

// ─── Destination URLs ─────────────────────────────────────────────────────────
const DESTINATION_URLS = {
  claude: 'https://claude.ai/new',
  gemini: 'https://gemini.google.com/',
  chatgpt: 'https://chatgpt.com/',
};


// ─── Error capture ────────────────────────────────────────────────────────────
const _capturedErrors = [];
const MAX_ERRORS = 10;

window.addEventListener('error', (event) => {
  if (_capturedErrors.length >= MAX_ERRORS) return;
  _capturedErrors.push({
    message: event.message,
    source: event.filename,
    line: event.lineno,
    column: event.colno,
    timestamp: new Date().toISOString(),
  });
});

window.addEventListener('unhandledrejection', (event) => {
  if (_capturedErrors.length >= MAX_ERRORS) return;
  _capturedErrors.push({
    message: event.reason?.message || String(event.reason),
    type: 'unhandledrejection',
    timestamp: new Date().toISOString(),
  });
});

// ─── Analytics ────────────────────────────────────────────────────────────────
async function getDistinctId() {
  return new Promise((resolve) => {
    chrome.storage.local.get('drewery_distinct_id', (data) => {
      resolve(data.drewery_distinct_id || 'drewery-popup-unknown');
    });
  });
}

async function trackEvent(eventName, properties) {
  if (!POSTHOG_API_KEY || POSTHOG_API_KEY === 'INSERT_POSTHOG_API_KEY_HERE') return;
  try {
    const distinctId = await getDistinctId();
    fetch(POSTHOG_HOST + '/capture/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        api_key: POSTHOG_API_KEY,
        event: eventName,
        distinct_id: distinctId,
        properties: Object.assign({ $lib: 'portility-extension', $lib_version: '1.1.0' }, properties || {}),
        timestamp: new Date().toISOString(),
      }),
      keepalive: true,
    }).catch(() => {});
  } catch (e) {}
}

// ─── Bug report ───────────────────────────────────────────────────────────────
const sessionStart = Date.now();

async function getActiveTabDomain() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0]?.url) {
        try {
          resolve(new URL(tabs[0].url).hostname);
        } catch (e) {
          resolve('unknown');
        }
      } else {
        resolve('unknown');
      }
    });
  });
}

async function submitBugReport(userNote) {
  const manifest = chrome.runtime.getManifest();
  const domain = await getActiveTabDomain();

  await trackEvent('bug_report_submitted', {
    extensionVersion: manifest.version,
    extensionName: manifest.name,
    userAgent: navigator.userAgent,
    platform: navigator.platform,
    language: navigator.language,
    screenResolution: window.screen.width + 'x' + window.screen.height,
    windowSize: window.innerWidth + 'x' + window.innerHeight,
    activeTabDomain: domain,
    timestamp: new Date().toISOString(),
    sessionDuration: Math.round((Date.now() - sessionStart) / 1000) + 's',
    recentErrors: _capturedErrors.slice(),
    errorCount: _capturedErrors.length,
    userNote: (userNote || '').trim().slice(0, 500),
    reportType: 'user_initiated',
  });

  _capturedErrors.length = 0;
}

// ─── Moderation check via proxy ──────────────────────────────────────────────
async function checkModeration(text) {
  var proxyBase = (typeof PROXY_URL !== 'undefined' && PROXY_URL !== 'YOUR_WORKER_URL') ? PROXY_URL : '';
  if (!proxyBase) {
    return { flagged: false, categories: {} };
  }

  try {
    var response = await fetch(proxyBase + '/moderate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ input: text }),
    });

    if (!response.ok) {
      return { flagged: false, categories: {} };
    }

    var data = await response.json();
    var result = data.results && data.results[0];
    if (!result) {
      return { flagged: false, categories: {} };
    }

    return {
      flagged: result.flagged || false,
      categories: result.categories || {},
    };
  } catch (e) {
    return { flagged: false, categories: {} };
  }
}

// ─── DOM ready ────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // ── Element references ────────────────────────────────────────────────────
  const screen1 = document.getElementById('screen1');
  const screen2 = document.getElementById('screen2');
  const screen2Label = document.getElementById('screen2Label');

  const copyBtn = document.getElementById('copyBtn');
  const statusEl = document.getElementById('status');

  const backBtn = document.getElementById('backBtn');
  const claudeDestBtn = document.getElementById('claudeDestBtn');
  const geminiDestBtn = document.getElementById('geminiDestBtn');
  const chatgptDestBtn = document.getElementById('chatgptDestBtn');
  const saveDestBtn = document.getElementById('saveDestBtn');
  const screen2StatusEl = document.getElementById('screen2Status');

  const bugBtn = document.getElementById('bugBtn');
  const featureBtn = document.getElementById('featureBtn');
  const bugStatusEl = document.getElementById('bugStatus');

  const destBtns = [claudeDestBtn, geminiDestBtn, chatgptDestBtn, saveDestBtn];

  // ── Port Operating Instructions elements ──────────────────────────────────
  const portInstructionsBtn = document.getElementById('portInstructionsBtn');
  const portStatusEl = document.getElementById('portStatus');
  const editInstructionsBtn = document.getElementById('editInstructionsBtn');

  // ── Passphrase modal elements ─────────────────────────────────────────────
  const passphraseModal = document.getElementById('passphraseModal');
  const portPassphraseInput = document.getElementById('portPassphraseInput');
  const portPassphraseError = document.getElementById('portPassphraseError');
  const portPassphraseBtn = document.getElementById('portPassphraseBtn');
  const portPassphraseCancelBtn = document.getElementById('portPassphraseCancelBtn');

  // ── Questionnaire elements ────────────────────────────────────────────────
  const questionnaireEl = document.getElementById('questionnaire');
  const qStartBtn = document.getElementById('qStartBtn');
  const q2OtherArea = document.getElementById('q2OtherArea');
  const q2OtherText = document.getElementById('q2OtherText');
  const q3OtherArea = document.getElementById('q3OtherArea');
  const q3OtherText = document.getElementById('q3OtherText');
  const q5Text = document.getElementById('q5Text');
  const q5NextBtn = document.getElementById('q5NextBtn');
  const q5SkipBtn = document.getElementById('q5SkipBtn');
  const qPassphrase = document.getElementById('qPassphrase');
  const qPassphraseConfirm = document.getElementById('qPassphraseConfirm');
  const qPassphraseError = document.getElementById('qPassphraseError');
  const qPassphraseBtn = document.getElementById('qPassphraseBtn');
  const qSaveError = document.getElementById('qSaveError');
  const qClaudeDestBtn = document.getElementById('qClaudeDestBtn');
  const qGeminiDestBtn = document.getElementById('qGeminiDestBtn');
  const qChatgptDestBtn = document.getElementById('qChatgptDestBtn');
  const qSaveDestBtn = document.getElementById('qSaveDestBtn');
  const qSkipDoneBtn = document.getElementById('qSkipDoneBtn');

  // ── Moderation modal references ────────────────────────────────────────────
  const moderationOverlay = document.getElementById('moderationOverlay');
  const modalOkayBtn = document.getElementById('modalOkayBtn');
  const modalErrorBtn = document.getElementById('modalErrorBtn');
  const modalFeedbackArea = document.getElementById('modalFeedbackArea');
  const modalFeedbackText = document.getElementById('modalFeedbackText');
  const modalSubmitBtn = document.getElementById('modalSubmitBtn');
  const modalThanks = document.getElementById('modalThanks');

  // Variable to hold extracted text so we can clear it on moderation flag
  let _extractedConversationText = null;

  // ── Port mode state ────────────────────────────────────────────────────
  let _portMode = 'chat'; // 'chat' or 'instructions'
  let _decryptedInstructions = null;

  // ── Questionnaire state ─────────────────────────────────────────────────
  const SCREEN_ORDER = ['q-intro', 'q-step1', 'q-step2', 'q-step3', 'q-step4', 'q-step5', 'q-passphrase', 'q-tutorial'];
  let qAnswers = {
    communicationStyle: [],
    communicationStyle_customText: '',
    whatNotToDo: [],
    whatNotToDo_customText: '',
    confidentiality: null,
    multimodal: null,
    otherPreferences: '',
  };
  let qPassphraseValue = '';
  let isEditMode = false;
  let _justBuiltInstructions = null;

  // ═══════════════════════════════════════════════════════════════════════════
  // QUESTIONNAIRE FLOW
  // ═══════════════════════════════════════════════════════════════════════════

  function showQScreen(screenId) {
    var screens = questionnaireEl.querySelectorAll('.q-screen');
    for (var i = 0; i < screens.length; i++) {
      screens[i].classList.remove('active');
    }
    var target = document.getElementById(screenId);
    if (target) target.classList.add('active');
  }

  function startQuestionnaire(editMode) {
    isEditMode = !!editMode;
    document.body.classList.add('questionnaire-active');

    // If editing, load saved answers
    if (isEditMode) {
      chrome.storage.local.get('questionnaire_answers', function (data) {
        if (data.questionnaire_answers) {
          qAnswers = Object.assign({}, qAnswers, data.questionnaire_answers);
          prefillAnswers();
        }
        showQScreen('q-step1');
      });
    } else {
      showQScreen('q-intro');
    }

    trackEvent('questionnaire_started', { editMode: isEditMode });
  }

  function endQuestionnaire() {
    document.body.classList.remove('questionnaire-active');
    showNormalUI();
  }

  function prefillAnswers() {
    // Highlight previously selected options
    var allOptions = questionnaireEl.querySelectorAll('.q-option');
    for (var i = 0; i < allOptions.length; i++) {
      var opt = allOptions[i];
      var question = opt.getAttribute('data-question');
      var value = opt.getAttribute('data-value');
      var answer = qAnswers[question];

      // Handle both array (multi-select) and string (single-select) answers
      if (Array.isArray(answer)) {
        if (answer.indexOf(value) >= 0) {
          opt.classList.add('selected');
        } else {
          opt.classList.remove('selected');
        }
      } else {
        if (answer === value) {
          opt.classList.add('selected');
        } else {
          opt.classList.remove('selected');
        }
      }
    }

    // Pre-fill "Other" text fields for multi-select screens
    if (Array.isArray(qAnswers.communicationStyle) && qAnswers.communicationStyle.indexOf('other') >= 0 && qAnswers.communicationStyle_customText) {
      q2OtherText.value = qAnswers.communicationStyle_customText;
      q2OtherArea.classList.add('visible');
    }
    if (Array.isArray(qAnswers.whatNotToDo) && qAnswers.whatNotToDo.indexOf('other') >= 0 && qAnswers.whatNotToDo_customText) {
      q3OtherText.value = qAnswers.whatNotToDo_customText;
      q3OtherArea.classList.add('visible');
    }
    if (qAnswers.otherPreferences) {
      q5Text.value = qAnswers.otherPreferences;
    }
  }

  // ── Q option click handler ──────────────────────────────────────────────
  var allQOptions = questionnaireEl.querySelectorAll('.q-option');
  for (var i = 0; i < allQOptions.length; i++) {
    allQOptions[i].addEventListener('click', function () {
      var question = this.getAttribute('data-question');
      var value = this.getAttribute('data-value');
      var screen = this.closest('.q-screen');
      var isMultiSelect = screen.hasAttribute('data-multiselect');

      if (isMultiSelect) {
        // ── Multi-select: toggle selection ──
        this.classList.toggle('selected');

        // Update array in qAnswers
        var arr = qAnswers[question];
        if (!Array.isArray(arr)) { arr = []; qAnswers[question] = arr; }
        var idx = arr.indexOf(value);
        if (idx >= 0) {
          arr.splice(idx, 1);
        } else {
          arr.push(value);
        }

        // Show/hide "Other" textarea
        if (question === 'communicationStyle') {
          if (arr.indexOf('other') >= 0) {
            q2OtherArea.classList.add('visible');
            q2OtherText.focus();
          } else {
            q2OtherArea.classList.remove('visible');
            qAnswers.communicationStyle_customText = '';
          }
        } else if (question === 'whatNotToDo') {
          if (arr.indexOf('other') >= 0) {
            q3OtherArea.classList.add('visible');
            q3OtherText.focus();
          } else {
            q3OtherArea.classList.remove('visible');
            qAnswers.whatNotToDo_customText = '';
          }
        }
        // No auto-advance for multi-select
      } else {
        // ── Single-select: deselect siblings, store value, auto-advance ──
        var siblings = this.parentElement.querySelectorAll('.q-option[data-question="' + question + '"]');
        for (var j = 0; j < siblings.length; j++) {
          siblings[j].classList.remove('selected');
        }
        this.classList.add('selected');
        qAnswers[question] = value;

        // Auto-advance to next screen
        var currentId = screen.id;
        var currentIndex = SCREEN_ORDER.indexOf(currentId);
        if (currentIndex >= 0 && currentIndex < SCREEN_ORDER.length - 1) {
          showQScreen(SCREEN_ORDER[currentIndex + 1]);
        }
      }
    });
  }

  // ── Introduction "Let's Go" button ────────────────────────────────────────
  qStartBtn.addEventListener('click', function () {
    showQScreen('q-step1');
  });

  // ── Multi-select "Next" button handlers ──────────────────────────────────
  var allMultiNextBtns = questionnaireEl.querySelectorAll('.q-multi-next');
  for (var i = 0; i < allMultiNextBtns.length; i++) {
    allMultiNextBtns[i].addEventListener('click', function () {
      var screen = this.closest('.q-screen');
      var screenId = screen.id;
      var targetId = this.getAttribute('data-target');

      // Determine which question this screen handles
      var firstOption = screen.querySelector('.q-option');
      if (!firstOption) return;
      var question = firstOption.getAttribute('data-question');
      var arr = qAnswers[question];

      // Validate at least one option selected
      if (!Array.isArray(arr) || arr.length === 0) {
        return; // Silently do nothing — user must select at least one
      }

      // If "other" is selected, capture and validate the custom text
      if (arr.indexOf('other') >= 0) {
        var customText = '';
        if (question === 'communicationStyle') {
          customText = q2OtherText.value.trim();
          if (!customText) { q2OtherText.focus(); return; }
          qAnswers.communicationStyle_customText = customText;
        } else if (question === 'whatNotToDo') {
          customText = q3OtherText.value.trim();
          if (!customText) { q3OtherText.focus(); return; }
          qAnswers.whatNotToDo_customText = customText;
        }
      }

      showQScreen(targetId);
    });
  }

  // ── Q5 "Next" and "Skip" buttons ─────────────────────────────────────────
  q5NextBtn.addEventListener('click', function () {
    qAnswers.otherPreferences = q5Text.value.trim();
    showQScreen('q-passphrase');
  });

  q5SkipBtn.addEventListener('click', function () {
    qAnswers.otherPreferences = '';
    showQScreen('q-passphrase');
  });

  // ── Passphrase screen — validates, then auto-saves ──────────────────────
  qPassphraseBtn.addEventListener('click', async function () {
    var pass = qPassphrase.value;
    var confirm = qPassphraseConfirm.value;

    qPassphraseError.textContent = '';

    if (pass.length < 6) {
      qPassphraseError.textContent = 'Passphrase must be at least 6 characters.';
      return;
    }
    if (pass !== confirm) {
      qPassphraseError.textContent = 'Passphrases do not match.';
      return;
    }

    qPassphraseValue = pass;
    qPassphraseBtn.disabled = true;
    qPassphraseBtn.textContent = 'Saving\u2026';

    try {
      var instructions = buildInstructionPacket(qAnswers);
      _justBuiltInstructions = instructions;
      var auth = await ensureAuthenticated();
      await saveInstructionsToFirestore(instructions, qPassphraseValue, auth.token, auth.userId, qAnswers);

      // Store passphrase in session memory
      sessionStorage.setItem('passphrase_session', qPassphraseValue);

      // Store completion flag and answers locally
      await new Promise(function (resolve) {
        chrome.storage.local.set({
          questionnaire_completed: true,
          questionnaire_answers: qAnswers,
        }, resolve);
      });

      trackEvent('questionnaire_completed', { editMode: isEditMode });

      // Show tutorial
      showQScreen('q-tutorial');
    } catch (err) {
      qPassphraseError.textContent = err.message || 'Failed to save. Try again.';
    } finally {
      qPassphraseBtn.disabled = false;
      qPassphraseBtn.textContent = 'Set Passphrase';
    }
  });

  // ── Tutorial destination buttons ──────────────────────────────────────────
  function handleQTutorialDest(destination) {
    if (!_justBuiltInstructions) return;

    if (destination === 'save') {
      var blob = new Blob([_justBuiltInstructions], { type: 'text/plain' });
      var blobUrl = URL.createObjectURL(blob);
      chrome.downloads.download({
        url: blobUrl,
        filename: 'portility-instructions.txt',
        saveAs: true,
      }, function () {
        URL.revokeObjectURL(blobUrl);
      });
      trackEvent('questionnaire_dest_save', {});
    } else {
      navigator.clipboard.writeText(_justBuiltInstructions).then(function () {
        chrome.tabs.create({ url: DESTINATION_URLS[destination] });
        trackEvent('questionnaire_dest_port', { destination: destination });
      });
    }
    endQuestionnaire();
  }

  qClaudeDestBtn.addEventListener('click', function () { handleQTutorialDest('claude'); });
  qGeminiDestBtn.addEventListener('click', function () { handleQTutorialDest('gemini'); });
  qChatgptDestBtn.addEventListener('click', function () { handleQTutorialDest('chatgpt'); });
  qSaveDestBtn.addEventListener('click', function () { handleQTutorialDest('save'); });
  qSkipDoneBtn.addEventListener('click', function () { endQuestionnaire(); });

  // ═══════════════════════════════════════════════════════════════════════════
  // PORT OPERATING INSTRUCTIONS
  // ═══════════════════════════════════════════════════════════════════════════

  function showPassphraseModal() {
    portPassphraseInput.value = '';
    portPassphraseError.textContent = '';
    passphraseModal.classList.add('visible');
    portPassphraseInput.focus();
  }

  function hidePassphraseModal() {
    passphraseModal.classList.remove('visible');
  }

  var _editAfterPassphrase = false;
  var _chatInstructionsResolve = null; // Promise resolve for chat-mode passphrase flow

  portInstructionsBtn.addEventListener('click', async function () {
    // If questionnaire not completed yet, launch it first
    var completed = await new Promise(function (resolve) {
      chrome.storage.local.get('questionnaire_completed', function (data) {
        resolve(!!data.questionnaire_completed);
      });
    });

    if (!completed) {
      startQuestionnaire(false);
      return;
    }

    _portMode = 'instructions';

    // Check if passphrase is in session memory
    var sessionPassphrase = sessionStorage.getItem('passphrase_session');

    if (sessionPassphrase) {
      // Passphrase in session — decrypt and show destination picker
      try {
        setPortStatus('Decrypting\u2026');
        portInstructionsBtn.disabled = true;
        _decryptedInstructions = await fetchAndDecryptInstructions(sessionPassphrase);
        setPortStatus('');
        portInstructionsBtn.disabled = false;
        screen2Label.textContent = 'Port instructions to\u2026';
        setScreen2Status('');
        setAllDestBtnsDisabled(false);
        showScreen('screen2');
      } catch (err) {
        portInstructionsBtn.disabled = false;
        if (err.message && err.message.includes('Incorrect passphrase')) {
          sessionStorage.removeItem('passphrase_session');
          setPortStatus('');
          showPassphraseModal();
        } else {
          setPortStatus(err.message || 'Something went wrong.', true);
        }
      }
    } else {
      // Prompt for passphrase
      showPassphraseModal();
    }
  });

  // Passphrase modal — Decrypt button
  portPassphraseBtn.addEventListener('click', async function () {
    var passphrase = portPassphraseInput.value;
    if (!passphrase) {
      portPassphraseError.textContent = 'Enter your passphrase.';
      return;
    }

    portPassphraseBtn.disabled = true;
    portPassphraseBtn.textContent = 'Decrypting\u2026';
    portPassphraseError.textContent = '';

    try {
      if (_editAfterPassphrase) {
        // Edit mode: verify passphrase works, then redirect to questionnaire
        await fetchAndDecryptInstructions(passphrase);
        sessionStorage.setItem('passphrase_session', passphrase);
        hidePassphraseModal();
        _editAfterPassphrase = false;
        startQuestionnaire(true);
      } else if (_portMode === 'instructions') {
        // Instructions port mode: decrypt and show destination picker
        _decryptedInstructions = await fetchAndDecryptInstructions(passphrase);
        sessionStorage.setItem('passphrase_session', passphrase);
        hidePassphraseModal();
        screen2Label.textContent = 'Port instructions to\u2026';
        setScreen2Status('');
        setAllDestBtnsDisabled(false);
        showScreen('screen2');
      } else if (_chatInstructionsResolve) {
        // Chat mode: decrypt instructions to prepend to conversation
        var chatInstructions = await fetchAndDecryptInstructions(passphrase);
        sessionStorage.setItem('passphrase_session', passphrase);
        hidePassphraseModal();
        _chatInstructionsResolve(chatInstructions);
        _chatInstructionsResolve = null;
      } else {
        // Fallback: just verify passphrase
        await fetchAndDecryptInstructions(passphrase);
        sessionStorage.setItem('passphrase_session', passphrase);
        hidePassphraseModal();
      }
    } catch (err) {
      portPassphraseError.textContent = err.message || 'Incorrect passphrase. Try again.';
      sessionStorage.removeItem('passphrase_session');
    } finally {
      portPassphraseBtn.disabled = false;
      portPassphraseBtn.textContent = 'Decrypt';
    }
  });

  // Passphrase modal — Cancel button
  portPassphraseCancelBtn.addEventListener('click', function () {
    _editAfterPassphrase = false;
    if (_chatInstructionsResolve) {
      _chatInstructionsResolve(null);
      _chatInstructionsResolve = null;
    }
    hidePassphraseModal();
  });

  // Allow Enter key in passphrase modal
  portPassphraseInput.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') {
      portPassphraseBtn.click();
    }
  });

  /**
   * Fetch and decrypt instructions from Firestore.
   * Handles token expiry with automatic re-auth.
   * @param {string} passphrase
   * @returns {Promise<string>} Decrypted instructions text
   */
  async function fetchAndDecryptInstructions(passphrase) {
    try {
      var token = await getGoogleAccessToken(false);
      var userId = await getGoogleUserId();
      var data = await getInstructionsFromFirestore(token, userId);
      if (!data) {
        throw new Error('No operating instructions saved yet. Run the questionnaire first.');
      }
      return await decryptInstructions(
        { encrypted: data.encrypted, salt: data.salt, iv: data.iv },
        passphrase
      );
    } catch (err) {
      // If token expired, try re-auth
      if (err.message && err.message.includes('Token expired')) {
        var auth = await ensureAuthenticated();
        var data2 = await getInstructionsFromFirestore(auth.token, auth.userId);
        if (!data2) throw new Error('No operating instructions found.');
        return await decryptInstructions(
          { encrypted: data2.encrypted, salt: data2.salt, iv: data2.iv },
          passphrase
        );
      }
      throw err;
    }
  }

  /**
   * Try to retrieve decrypted operating instructions for the chat port flow.
   * Returns the instructions text if available, or null if skipped/unavailable.
   */
  async function tryGetInstructions() {
    // Check if questionnaire has been completed
    var completed = await new Promise(function (resolve) {
      chrome.storage.local.get('questionnaire_completed', function (data) {
        resolve(!!data.questionnaire_completed);
      });
    });

    if (!completed) return null;

    // Check for cached passphrase in session
    var sessionPassphrase = sessionStorage.getItem('passphrase_session');

    if (sessionPassphrase) {
      try {
        return await fetchAndDecryptInstructions(sessionPassphrase);
      } catch (e) {
        // Passphrase was stale — clear it and fall through to ask user
        sessionStorage.removeItem('passphrase_session');
      }
    }

    // Ask user if they want to include their operating instructions
    var include = confirm('Include your operating instructions with this conversation?');
    if (!include) return null;

    // Need passphrase — show modal and wait for result
    return new Promise(function (resolve) {
      _chatInstructionsResolve = resolve;
      showPassphraseModal();
    });
  }

  function setPortStatus(msg, isError) {
    if (!portStatusEl) return;
    portStatusEl.textContent = msg;
    portStatusEl.style.fontSize = '11px';
    portStatusEl.style.marginTop = msg ? '6px' : '0';
    portStatusEl.style.color = isError ? '#dc2626' : '#6b7280';
    portStatusEl.style.lineHeight = '1.4';
  }

  // ── Edit Instructions button ──────────────────────────────────────────────
  editInstructionsBtn.addEventListener('click', function () {
    // Prompt for passphrase to verify identity before editing
    var sessionPassphrase = sessionStorage.getItem('passphrase_session');
    if (sessionPassphrase) {
      startQuestionnaire(true);
    } else {
      // Show passphrase modal; on success, the modal handler checks
      // _editAfterPassphrase and redirects to questionnaire
      _editAfterPassphrase = true;
      showPassphraseModal();
    }
  });

  // ═══════════════════════════════════════════════════════════════════════════
  // NORMAL UI SETUP
  // ═══════════════════════════════════════════════════════════════════════════

  function showNormalUI() {
    // Show edit link if questionnaire has been completed previously
    chrome.storage.local.get('questionnaire_completed', function (data) {
      if (data.questionnaire_completed) {
        editInstructionsBtn.style.display = 'inline';
      }
    });
  }

  // ── Moderation modal handlers ─────────────────────────────────────────────
  function showModerationModal() {
    modalFeedbackArea.style.display = 'none';
    modalFeedbackText.value = '';
    modalThanks.style.display = 'none';
    modalOkayBtn.style.display = 'block';
    modalErrorBtn.style.display = 'block';
    modalSubmitBtn.disabled = false;
    moderationOverlay.classList.add('visible');
  }

  function hideModerationModal() {
    moderationOverlay.classList.remove('visible');
  }

  function clearExtractedContext() {
    _extractedConversationText = null;
  }

  modalOkayBtn.addEventListener('click', function () {
    clearExtractedContext();
    hideModerationModal();
    setScreen2Status('');
    setAllDestBtnsDisabled(false);
  });

  modalErrorBtn.addEventListener('click', function () {
    modalOkayBtn.style.display = 'none';
    modalErrorBtn.style.display = 'none';
    modalFeedbackArea.style.display = 'block';
  });

  modalSubmitBtn.addEventListener('click', function () {
    const feedbackText = (modalFeedbackText.value || '').trim();
    if (!feedbackText) return;

    modalSubmitBtn.disabled = true;

    const webhookUrl = (typeof GOOGLE_SHEET_WEBHOOK !== 'undefined') ? GOOGLE_SHEET_WEBHOOK : 'YOUR_GOOGLE_SHEET_WEBHOOK';

    fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        feedback: feedbackText,
        timestamp: new Date().toISOString(),
        source: 'portility-moderation-appeal',
      }),
      mode: 'no-cors',
    }).catch(function (e) {
    }).then(function () {
      modalFeedbackArea.style.display = 'none';
      modalThanks.style.display = 'block';

      setTimeout(function () {
        clearExtractedContext();
        hideModerationModal();
        setScreen2Status('');
        setAllDestBtnsDisabled(false);
      }, 2000);
    });
  });

  // ── Screen switching ──────────────────────────────────────────────────────
  function showScreen(id) {
    screen1.style.display = id === 'screen1' ? 'block' : 'none';
    screen2.style.display = id === 'screen2' ? 'block' : 'none';
  }

  // ── Status helpers ────────────────────────────────────────────────────────
  function setStatus(msg, isError) {
    statusEl.textContent = msg;
    statusEl.className = isError ? 'error' : '';
  }

  function setScreen2Status(msg, isError) {
    screen2StatusEl.textContent = msg;
    screen2StatusEl.className = isError ? 'error' : '';
  }

  function setAllDestBtnsDisabled(disabled) {
    destBtns.forEach((btn) => { btn.disabled = disabled; });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // FIRST-LAUNCH DETECTION
  // ═══════════════════════════════════════════════════════════════════════════

  // Always show normal UI on every launch
  showNormalUI();

  // ── Check if active tab has a conversation ────────────────────────────────
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs && tabs[0];
    if (!tab || !tab.url) {
      setStatus('Open a conversation on Claude, ChatGPT, or Gemini to get started.');
      return;
    }

    const url = tab.url;
    const isSupported = /claude\.ai/i.test(url) || /chatgpt\.com/i.test(url) || /gemini\.google\.com/i.test(url);

    if (!isSupported) {
      setStatus('Open a conversation on Claude, ChatGPT, or Gemini to get started.');
      return;
    }

    chrome.tabs.sendMessage(tab.id, { type: 'PING' }, (response) => {
      if (chrome.runtime.lastError || !response) {
        setStatus('');
        return;
      }
      setStatus('');
    });
  });

  // ─── Port Your Conversation button → show Screen 2 ────────────────────────
  copyBtn.addEventListener('click', () => {
    _portMode = 'chat';
    screen2Label.textContent = 'Port conversation to\u2026';
    setScreen2Status('');
    setAllDestBtnsDisabled(false);
    showScreen('screen2');
  });

  // ─── Back button ──────────────────────────────────────────────────────────
  backBtn.addEventListener('click', () => {
    _portMode = 'chat';
    _decryptedInstructions = null;
    showScreen('screen1');
  });

  // ─── Destination handler ──────────────────────────────────────────────────
  async function handleDestination(destination) {
    setAllDestBtnsDisabled(true);

    // ── Instructions mode: already decrypted, just copy/save ──
    if (_portMode === 'instructions') {
      try {
        if (!_decryptedInstructions) {
          throw new Error('No decrypted instructions available.');
        }

        if (destination === 'save') {
          var blob = new Blob([_decryptedInstructions], { type: 'text/plain' });
          var blobUrl = URL.createObjectURL(blob);
          chrome.downloads.download({
            url: blobUrl,
            filename: 'portility-instructions.txt',
            saveAs: true,
          }, function () {
            URL.revokeObjectURL(blobUrl);
          });
          setScreen2Status('Instructions saved!');
          trackEvent('operating_instructions_saved', { destination: 'file' });
        } else {
          await navigator.clipboard.writeText(_decryptedInstructions);
          chrome.tabs.create({ url: DESTINATION_URLS[destination] });
          setScreen2Status('Instructions copied \u2014 paste them in the new tab!');
          trackEvent('operating_instructions_ported', { destination: destination });
        }
      } catch (err) {
        setScreen2Status(err.message || 'Something went wrong.', true);
        setAllDestBtnsDisabled(false);
      }
      return;
    }

    // ── Chat mode: extract from page ──
    setScreen2Status('Extracting\u2026');

    try {
      const tabs = await new Promise((resolve) => {
        chrome.tabs.query({ active: true, currentWindow: true }, resolve);
      });
      const tab = tabs && tabs[0];
      if (!tab || !tab.id) throw new Error('No active tab found.');

      const response = await new Promise((resolve, reject) => {
        chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT', skipClipboard: true }, (resp) => {
          if (chrome.runtime.lastError) {
            reject(new Error('Could not reach the page \u2014 try refreshing.'));
            return;
          }
          if (!resp || !resp.success) {
            reject(new Error(resp?.error || 'Extraction failed.'));
            return;
          }
          resolve(resp);
        });
      });

      const conversationText = response.text;
      _extractedConversationText = conversationText;

      trackEvent('portility_extract_initiated', {
        destination: destination,
        message_count: response.messageCount,
      });

      setScreen2Status('Checking content\u2026');
      const moderationResult = await checkModeration(conversationText);
      if (moderationResult.flagged) {
        trackEvent('portility_moderation_flagged', {
          destination: destination,
          categories: moderationResult.categories,
        });
        showModerationModal();
        return;
      }

      // Try to include operating instructions if available
      var instructions = await tryGetInstructions();
      var finalText = conversationText;
      if (instructions) {
        finalText = instructions + '\n\n---\n\n' + conversationText;
      }

      if (destination === 'save') {
        const blob = new Blob([finalText], { type: 'text/plain' });
        const blobUrl = URL.createObjectURL(blob);

        chrome.downloads.download({
          url: blobUrl,
          filename: 'portility-conversation.txt',
          saveAs: true,
        }, () => {
          URL.revokeObjectURL(blobUrl);
        });

        setScreen2Status('Conversation saved!');
        trackEvent('portility_save_success', { destination: 'file', instructions_included: !!instructions });
      } else {
        await navigator.clipboard.writeText(finalText);
        chrome.tabs.create({ url: DESTINATION_URLS[destination] });
        setScreen2Status('Conversation copied \u2014 paste it in the new tab!');
        trackEvent('portility_port_success', { destination: destination, instructions_included: !!instructions });
      }
    } catch (err) {
      setScreen2Status(err.message || 'Something went wrong.', true);
      setAllDestBtnsDisabled(false);
      trackEvent('portility_port_failed', {
        destination: destination,
        error: err.message,
      });
    }
  }

  // ─── Destination button listeners ─────────────────────────────────────────
  claudeDestBtn.addEventListener('click', () => handleDestination('claude'));
  geminiDestBtn.addEventListener('click', () => handleDestination('gemini'));
  chatgptDestBtn.addEventListener('click', () => handleDestination('chatgpt'));
  saveDestBtn.addEventListener('click', () => handleDestination('save'));

  // ─── Bug report ───────────────────────────────────────────────────────────
  bugBtn.addEventListener('click', () => {
    const note = prompt('Describe the issue (optional):');
    if (note === null) return;

    bugBtn.disabled = true;
    bugStatusEl.textContent = 'Sending\u2026';
    bugStatusEl.className = '';

    submitBugReport(note).then(() => {
      bugStatusEl.textContent = 'Bug report sent \u2014 thank you!';
      bugStatusEl.className = 'sent';
      setTimeout(() => {
        bugBtn.disabled = false;
        bugStatusEl.textContent = '';
        bugStatusEl.className = '';
      }, 3000);
    }).catch(() => {
      bugStatusEl.textContent = 'Failed to send \u2014 try again.';
      bugBtn.disabled = false;
    });
  });

  // ─── Feature request ──────────────────────────────────────────────────────
  featureBtn.addEventListener('click', () => {
    chrome.tabs.create({ url: FEATURE_REQUEST_URL });
  });
});
