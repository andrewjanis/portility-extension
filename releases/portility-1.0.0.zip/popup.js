/**
 * popup.js
 * The Drewery — extension popup.
 *
 * Handles:
 *   - Copy Conversation: shows Screen 2, user picks destination, extracts + copies raw conversation
 *   - Summarize: shows Screen 2, user picks destination, extracts + summarizes
 *     via Claude API, prepends destination instructions, copies + opens new tab
 *   - Save as .txt: downloads content as a text file
 *   - Request a Feature: opens Google Form in new tab
 *   - Bug Report: collects metadata + optional note, sends to PostHog
 *   - Error capture: silently collects JS errors during popup session
 */

'use strict';

// ─── Config ───────────────────────────────────────────────────────────────────
const POSTHOG_API_KEY = 'phc_Am8QxJfBbaSQVfEbANuaPVWWfeEWoKQEqK7QKo38Y9fD';
const POSTHOG_HOST = 'https://app.posthog.com';
// PROXY_URL, GOOGLE_SHEET_WEBHOOK are loaded from config.js (via script tag in popup.html)
const FEATURE_REQUEST_URL = 'https://docs.google.com/forms/d/e/1FAIpQLSeCMXd1I6-I0G0y3rl5C8a0Cl2qlrVXuwjtpa138eeaEnq_OQ/viewform?usp=dialog';

// ─── Destination URLs ─────────────────────────────────────────────────────────
const DESTINATION_URLS = {
  claude: 'https://claude.ai/new',
  gemini: 'https://gemini.google.com/',
  chatgpt: 'https://chatgpt.com/',
};

// ─── Instruction file paths (relative to extension root) ──────────────────────
const INSTRUCTION_FILES = {
  claude: 'claude-instructions.txt',
  gemini: 'gemini-instructions.txt',
  chatgpt: 'chatgpt-instructions.txt',
};

// ─── Error capture ────────────────────────────────────────────────────────────
const _capturedErrors = [];
const MAX_ERRORS = 10;

window.addEventListener('error', (event) => {
  if (_capturedErrors.length >= MAX_ERRORS) return;
  _capturedErrors.push({
    message: event.message,
    source: event.filename,
    line: event.lineno,
    column: event.colno,
    timestamp: new Date().toISOString(),
  });
});

window.addEventListener('unhandledrejection', (event) => {
  if (_capturedErrors.length >= MAX_ERRORS) return;
  _capturedErrors.push({
    message: event.reason?.message || String(event.reason),
    type: 'unhandledrejection',
    timestamp: new Date().toISOString(),
  });
});

// ─── Analytics ────────────────────────────────────────────────────────────────
async function getDistinctId() {
  return new Promise((resolve) => {
    chrome.storage.local.get('drewery_distinct_id', (data) => {
      resolve(data.drewery_distinct_id || 'drewery-popup-unknown');
    });
  });
}

async function trackEvent(eventName, properties) {
  if (!POSTHOG_API_KEY || POSTHOG_API_KEY === 'INSERT_POSTHOG_API_KEY_HERE') return;
  try {
    const distinctId = await getDistinctId();
    fetch(POSTHOG_HOST + '/capture/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        api_key: POSTHOG_API_KEY,
        event: eventName,
        distinct_id: distinctId,
        properties: Object.assign({ $lib: 'drewery-extension', $lib_version: '1.0.0' }, properties || {}),
        timestamp: new Date().toISOString(),
      }),
      keepalive: true,
    }).catch(() => {});
  } catch (e) {}
}

// ─── Bug report ───────────────────────────────────────────────────────────────
const sessionStart = Date.now();

async function getActiveTabDomain() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0]?.url) {
        try {
          resolve(new URL(tabs[0].url).hostname);
        } catch (e) {
          resolve('unknown');
        }
      } else {
        resolve('unknown');
      }
    });
  });
}

async function submitBugReport(userNote) {
  const manifest = chrome.runtime.getManifest();
  const domain = await getActiveTabDomain();

  await trackEvent('bug_report_submitted', {
    extensionVersion: manifest.version,
    extensionName: manifest.name,
    userAgent: navigator.userAgent,
    platform: navigator.platform,
    language: navigator.language,
    screenResolution: window.screen.width + 'x' + window.screen.height,
    windowSize: window.innerWidth + 'x' + window.innerHeight,
    activeTabDomain: domain,
    timestamp: new Date().toISOString(),
    sessionDuration: Math.round((Date.now() - sessionStart) / 1000) + 's',
    recentErrors: _capturedErrors.slice(),
    errorCount: _capturedErrors.length,
    userNote: (userNote || '').trim().slice(0, 500),
    reportType: 'user_initiated',
  });

  _capturedErrors.length = 0;
}

// ─── Load destination instruction file ───────────────────────────────────────
async function loadInstructions(destination) {
  const filename = INSTRUCTION_FILES[destination];
  if (!filename) return '';
  try {
    const url = chrome.runtime.getURL(filename);
    const response = await fetch(url);
    if (!response.ok) throw new Error('File not found');
    return (await response.text()).trim();
  } catch (e) {
    return 'The following is a summary of a previous conversation from another AI assistant. Treat it as shared context. In your first response, briefly confirm what you understand the conversation to be about, then propose the most logical next step and ask the user if they\'d like to proceed with that or go in a different direction.';
  }
}

// ─── Summarization via proxy ──────────────────────────────────────────────────
async function summarizeWithClaude(conversationText) {
  var proxyBase = (typeof PROXY_URL !== 'undefined' && PROXY_URL !== 'YOUR_WORKER_URL') ? PROXY_URL : '';
  if (!proxyBase) throw new Error('Proxy URL not configured.');

  var response = await fetch(proxyBase + '/summarize', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text: conversationText }),
  });

  if (!response.ok) {
    var err = await response.json().catch(function () { return {}; });
    throw new Error(err?.error?.message || 'Summarization failed: ' + response.status);
  }

  var data = await response.json();
  return data.content[0].text;
}

// ─── Moderation check via proxy ──────────────────────────────────────────────
async function checkModeration(text) {
  var proxyBase = (typeof PROXY_URL !== 'undefined' && PROXY_URL !== 'YOUR_WORKER_URL') ? PROXY_URL : '';
  if (!proxyBase) {
    // Proxy not configured — skip moderation
    return { flagged: false, categories: {} };
  }

  try {
    var response = await fetch(proxyBase + '/moderate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ input: text }),
    });

    if (!response.ok) {
      return { flagged: false, categories: {} };
    }

    var data = await response.json();
    var result = data.results && data.results[0];
    if (!result) {
      return { flagged: false, categories: {} };
    }

    return {
      flagged: result.flagged || false,
      categories: result.categories || {},
    };
  } catch (e) {
    return { flagged: false, categories: {} };
  }
}

// ─── DOM ready ────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // ── Element references ────────────────────────────────────────────────────
  const screen1 = document.getElementById('screen1');
  const screen2 = document.getElementById('screen2');
  const screen2Label = document.getElementById('screen2Label');

  const copyBtn = document.getElementById('copyBtn');
  const summarizeBtn = document.getElementById('summarizeBtn');
  const statusEl = document.getElementById('status');

  const backBtn = document.getElementById('backBtn');
  const claudeDestBtn = document.getElementById('claudeDestBtn');
  const geminiDestBtn = document.getElementById('geminiDestBtn');
  const chatgptDestBtn = document.getElementById('chatgptDestBtn');
  const saveDestBtn = document.getElementById('saveDestBtn');
  const screen2StatusEl = document.getElementById('screen2Status');

  const bugBtn = document.getElementById('bugBtn');
  const featureBtn = document.getElementById('featureBtn');
  const bugStatusEl = document.getElementById('bugStatus');

  const destBtns = [claudeDestBtn, geminiDestBtn, chatgptDestBtn, saveDestBtn];

  // ── Moderation modal references ────────────────────────────────────────────
  const moderationOverlay = document.getElementById('moderationOverlay');
  const modalOkayBtn = document.getElementById('modalOkayBtn');
  const modalErrorBtn = document.getElementById('modalErrorBtn');
  const modalFeedbackArea = document.getElementById('modalFeedbackArea');
  const modalFeedbackText = document.getElementById('modalFeedbackText');
  const modalSubmitBtn = document.getElementById('modalSubmitBtn');
  const modalThanks = document.getElementById('modalThanks');

  // Variable to hold extracted text so we can clear it on moderation flag
  let _extractedConversationText = null;

  function showModerationModal() {
    // Reset modal to initial state
    modalFeedbackArea.style.display = 'none';
    modalFeedbackText.value = '';
    modalThanks.style.display = 'none';
    modalOkayBtn.style.display = 'block';
    modalErrorBtn.style.display = 'block';
    modalSubmitBtn.disabled = false;
    moderationOverlay.classList.add('visible');
  }

  function hideModerationModal() {
    moderationOverlay.classList.remove('visible');
  }

  function clearExtractedContext() {
    _extractedConversationText = null;
  }

  // ── "Okay" button — close modal, clear context, re-enable buttons ─────────
  modalOkayBtn.addEventListener('click', function () {
    clearExtractedContext();
    hideModerationModal();
    setScreen2Status('');
    setAllDestBtnsDisabled(false);
  });

  // ── "This is an error" button — show feedback textarea ─────────────────────
  modalErrorBtn.addEventListener('click', function () {
    modalOkayBtn.style.display = 'none';
    modalErrorBtn.style.display = 'none';
    modalFeedbackArea.style.display = 'block';
  });

  // ── Submit feedback to Google Sheet webhook ────────────────────────────────
  modalSubmitBtn.addEventListener('click', function () {
    const feedbackText = (modalFeedbackText.value || '').trim();
    if (!feedbackText) return;

    modalSubmitBtn.disabled = true;

    // POST feedback to Google Sheet webhook
    const webhookUrl = (typeof GOOGLE_SHEET_WEBHOOK !== 'undefined') ? GOOGLE_SHEET_WEBHOOK : 'YOUR_GOOGLE_SHEET_WEBHOOK';

    fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        feedback: feedbackText,
        timestamp: new Date().toISOString(),
        source: 'drewery-moderation-appeal',
      }),
      mode: 'no-cors',
    }).catch(function (e) {
      // Silently fail — we still show the thank-you message
    }).then(function () {
      // Show thanks message
      modalFeedbackArea.style.display = 'none';
      modalThanks.style.display = 'block';

      // Close modal after 2 seconds
      setTimeout(function () {
        clearExtractedContext();
        hideModerationModal();
        setScreen2Status('');
        setAllDestBtnsDisabled(false);
      }, 2000);
    });
  });

  // ── Screen switching ──────────────────────────────────────────────────────
  function showScreen(id) {
    screen1.style.display = id === 'screen1' ? 'block' : 'none';
    screen2.style.display = id === 'screen2' ? 'block' : 'none';
  }

  // ── Status helpers ────────────────────────────────────────────────────────
  function setStatus(msg, isError) {
    statusEl.textContent = msg;
    statusEl.className = isError ? 'error' : '';
  }

  function setScreen2Status(msg, isError) {
    screen2StatusEl.textContent = msg;
    screen2StatusEl.className = isError ? 'error' : '';
  }

  function setAllDestBtnsDisabled(disabled) {
    destBtns.forEach((btn) => { btn.disabled = disabled; });
  }

  // ── Check if active tab has a conversation ────────────────────────────────
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs && tabs[0];
    if (!tab || !tab.url) {
      setStatus('Open a Claude conversation to get started.');
      return;
    }

    // Check if we're on a supported site
    const url = tab.url;
    const isSupported = /claude\.ai/i.test(url);

    if (!isSupported) {
      setStatus('Open a Claude conversation to get started.');
      return;
    }

    // Ping content script to check for active conversation
    chrome.tabs.sendMessage(tab.id, { type: 'PING' }, (response) => {
      if (chrome.runtime.lastError || !response) {
        // Content script not loaded or no response — enable buttons anyway
        // since the conversation check happens at extraction time
        copyBtn.disabled = false;
        summarizeBtn.disabled = false;
        setStatus('Ready — click to copy or summarize.');
        return;
      }

      copyBtn.disabled = false;
      summarizeBtn.disabled = false;
      setStatus('Ready — click to copy or summarize.');
    });
  });

  // ─── Copy Conversation button → show Screen 2 ────────────────────────────
  copyBtn.addEventListener('click', () => {
    screen2Label.textContent = 'Copy conversation to\u2026';
    setScreen2Status('');
    setAllDestBtnsDisabled(false);
    showScreen('screen2');
  });

  // ─── Summarize button → show Screen 2 ────────────────────────────────────
  summarizeBtn.addEventListener('click', () => {
    screen2Label.textContent = 'Summarize & open in\u2026';
    setScreen2Status('');
    setAllDestBtnsDisabled(false);
    showScreen('screen2');
  });

  // ─── Back button ──────────────────────────────────────────────────────────
  backBtn.addEventListener('click', () => {
    showScreen('screen1');
  });

  // ─── Destination handler ──────────────────────────────────────────────────
  async function handleDestination(destination) {
    setAllDestBtnsDisabled(true);

    const isCopyMode = screen2Label.textContent.includes('Copy conversation');

    setScreen2Status(isCopyMode ? 'Extracting\u2026' : 'Extracting & summarizing\u2026');

    try {
      // 1. Extract conversation from content script
      const tabs = await new Promise((resolve) => {
        chrome.tabs.query({ active: true, currentWindow: true }, resolve);
      });
      const tab = tabs && tabs[0];
      if (!tab || !tab.id) throw new Error('No active tab found.');

      const response = await new Promise((resolve, reject) => {
        chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT', skipClipboard: true }, (resp) => {
          if (chrome.runtime.lastError) {
            reject(new Error('Could not reach the page — try refreshing.'));
            return;
          }
          if (!resp || !resp.success) {
            reject(new Error(resp?.error || 'Extraction failed.'));
            return;
          }
          resolve(resp);
        });
      });

      const conversationText = response.text;
      _extractedConversationText = conversationText;

      trackEvent('drewery_extract_initiated', {
        mode: isCopyMode ? 'copy' : 'summarize',
        destination: destination,
        message_count: response.messageCount,
      });

      // 1b. Moderation check — block if flagged
      setScreen2Status('Checking content\u2026');
      const moderationResult = await checkModeration(conversationText);
      if (moderationResult.flagged) {
        trackEvent('drewery_moderation_flagged', {
          mode: isCopyMode ? 'copy' : 'summarize',
          destination: destination,
          categories: moderationResult.categories,
        });
        showModerationModal();
        return;
      }

      // 2. Build final text based on mode
      let finalText;
      if (isCopyMode) {
        finalText = conversationText;
      } else {
        setScreen2Status('Summarizing with Claude\u2026');
        const summary = await summarizeWithClaude(conversationText);

        const instructions = destination !== 'save'
          ? await loadInstructions(destination)
          : 'The following is a summary of a previous conversation from another AI assistant. Treat it as shared context. In your first response, briefly confirm what you understand the conversation to be about, then propose the most logical next step and ask the user if they\'d like to proceed with that or go in a different direction.';

        finalText = instructions + '\n\n---\n\n' + summary;
      }

      // 3. Copy to clipboard or save as file
      if (destination === 'save') {
        // Download as .txt file
        const blob = new Blob([finalText], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const filename = isCopyMode ? 'drewery-conversation.txt' : 'drewery-summary.txt';

        chrome.downloads.download({
          url: url,
          filename: filename,
          saveAs: true,
        }, () => {
          URL.revokeObjectURL(url);
        });

        const successMsg = isCopyMode ? 'Conversation saved!' : 'Summary saved!';
        setScreen2Status(successMsg);
        trackEvent('drewery_save_success', { mode: isCopyMode ? 'copy' : 'summarize' });
      } else {
        // Copy to clipboard and open destination
        await navigator.clipboard.writeText(finalText);

        chrome.tabs.create({ url: DESTINATION_URLS[destination] });

        const successMsg = isCopyMode
          ? 'Conversation copied — paste it in the new tab!'
          : 'Summary copied — paste it in the new tab!';
        setScreen2Status(successMsg);
        trackEvent('drewery_port_success', {
          mode: isCopyMode ? 'copy' : 'summarize',
          destination: destination,
        });
      }
    } catch (err) {
      setScreen2Status(err.message || 'Something went wrong.', true);
      setAllDestBtnsDisabled(false);
      trackEvent('drewery_port_failed', {
        mode: isCopyMode ? 'copy' : 'summarize',
        destination: destination,
        error: err.message,
      });
    }
  }

  // ─── Destination button listeners ─────────────────────────────────────────
  claudeDestBtn.addEventListener('click', () => handleDestination('claude'));
  geminiDestBtn.addEventListener('click', () => handleDestination('gemini'));
  chatgptDestBtn.addEventListener('click', () => handleDestination('chatgpt'));
  saveDestBtn.addEventListener('click', () => handleDestination('save'));

  // ─── Bug report ───────────────────────────────────────────────────────────
  bugBtn.addEventListener('click', () => {
    const note = prompt('Describe the issue (optional):');
    if (note === null) return; // user cancelled

    bugBtn.disabled = true;
    bugStatusEl.textContent = 'Sending\u2026';
    bugStatusEl.className = '';

    submitBugReport(note).then(() => {
      bugStatusEl.textContent = 'Bug report sent — thank you!';
      bugStatusEl.className = 'sent';
      setTimeout(() => {
        bugBtn.disabled = false;
        bugStatusEl.textContent = '';
        bugStatusEl.className = '';
      }, 3000);
    }).catch(() => {
      bugStatusEl.textContent = 'Failed to send — try again.';
      bugBtn.disabled = false;
    });
  });

  // ─── Feature request ──────────────────────────────────────────────────────
  featureBtn.addEventListener('click', () => {
    chrome.tabs.create({ url: FEATURE_REQUEST_URL });
  });
});
