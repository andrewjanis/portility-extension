/**
 * artifact-curator.js
 * Portility — Version pruning and artifact curation.
 * Loaded in the popup context via script tag in popup.html.
 *
 * Tags artifacts as keeper/discard based on filename patterns.
 * Parses versioned filenames and auto-marks older versions as superseded.
 */
'use strict';

var DISCARD_PATTERNS = [
  /^Screenshot/i,
  /^IMG_/,
  /^Untitled/i,
  /^screen/i,
  /\.tmp$/i,
  /^temp/i,
  /^debug/i,
];

var KEEP_PATTERNS = [
  /Report/i,
  /Document/i,
  /Code/i,
  /Design/i,
  /Contract/i,
  /final/i,
  /\.pdf$/i,
  /\.docx$/i,
  /\.py$/i,
  /\.js$/i,
];

var ArtifactCurator = {

  /**
   * Tag a single artifact as keeper or discard based on filename patterns.
   * @param {string} filename
   * @returns {{tag: string, reason: string}}
   */
  tagArtifact: function (filename) {
    for (var i = 0; i < DISCARD_PATTERNS.length; i++) {
      if (DISCARD_PATTERNS[i].test(filename)) {
        return { tag: 'discard', reason: 'matches discard pattern' };
      }
    }
    for (var j = 0; j < KEEP_PATTERNS.length; j++) {
      if (KEEP_PATTERNS[j].test(filename)) {
        return { tag: 'keeper', reason: 'matches keep pattern' };
      }
    }
    return { tag: 'keeper', reason: 'default keep — no discard pattern matched' };
  },

  /**
   * Parse a versioned filename.
   * e.g., "code_v3.py" → { base: "code", version: 3, ext: ".py" }
   * @param {string} filename
   * @returns {{base: string, version: number, ext: string}|null}
   */
  parseVersion: function (filename) {
    var patterns = [
      /^(.+?)_v(\d+)(\.\w+)?$/i,   // code_v1.py
      /^(.+?)_(\d+)(\.\w+)?$/,      // code_1.py
      /^(.+?)\s\((\d+)\)(\.\w+)?$/, // code (1).py
    ];

    for (var i = 0; i < patterns.length; i++) {
      var match = filename.match(patterns[i]);
      if (match) {
        return {
          base: match[1].trim(),
          version: parseInt(match[2], 10),
          ext: match[3] || '',
        };
      }
    }
    return null;
  },

  /**
   * Find all older versions of a new file in the stored artifact list.
   * @param {string} newFilename
   * @param {Object} allArtifacts — map of name → artifact object
   * @returns {Array} artifacts to mark as superseded
   */
  pruneOldVersions: function (newFilename, allArtifacts) {
    var newParsed = this.parseVersion(newFilename);
    if (!newParsed) return [];

    var toSupersede = [];

    for (var name in allArtifacts) {
      if (!allArtifacts.hasOwnProperty(name)) continue;
      if (name === newFilename) continue;
      if (allArtifacts[name].status === 'superseded') continue;

      var oldParsed = this.parseVersion(name);
      if (!oldParsed) continue;

      var sameBase = oldParsed.base.toLowerCase() === newParsed.base.toLowerCase();
      var sameExt = oldParsed.ext.toLowerCase() === newParsed.ext.toLowerCase();
      var isOlder = oldParsed.version < newParsed.version;

      if (sameBase && sameExt && isOlder) {
        toSupersede.push({ name: name, driveId: allArtifacts[name].driveId || null });
      }
    }

    return toSupersede;
  },

  /**
   * Process a list of artifacts: tag each and prune old versions.
   * @param {Array} artifacts
   * @returns {Array} artifacts with tag and status fields added
   */
  curateArtifacts: function (artifacts) {
    // Build a map for version pruning
    var map = {};
    for (var i = 0; i < artifacts.length; i++) {
      var a = artifacts[i];
      var tag = this.tagArtifact(a.filename);
      a.tag = tag.tag;
      a.tagReason = tag.reason;
      if (!a.status) a.status = 'pending';
      map[a.filename] = a;
    }

    // Mark old versions as superseded
    for (var j = 0; j < artifacts.length; j++) {
      var toSupersede = this.pruneOldVersions(artifacts[j].filename, map);
      for (var k = 0; k < toSupersede.length; k++) {
        if (map[toSupersede[k].name]) {
          map[toSupersede[k].name].status = 'superseded';
          map[toSupersede[k].name].supersededBy = artifacts[j].filename;
        }
      }
    }

    return artifacts;
  },

  /**
   * Load artifacts from storage, curate, and save back.
   * @returns {Promise<Array>}
   */
  run: function () {
    var self = this;
    return new Promise(function (resolve) {
      chrome.storage.local.get('detected_artifacts', function (data) {
        var artifacts = data.detected_artifacts || [];
        var curated = self.curateArtifacts(artifacts);
        chrome.storage.local.set({ detected_artifacts: curated }, function () {
          resolve(curated);
        });
      });
    });
  },
};
