/**
 * selector-manager.js
 * Portility — Dynamic selector configuration fetched from GitHub.
 * Loaded as a content script BEFORE platform-specific scripts.
 * Exposes window.PortilitySelectors with platform-specific DOM selectors.
 */
(function () {
  'use strict';

  var GITHUB_RAW_URL = 'https://raw.githubusercontent.com/andrewjanis/portility-selectors/main/selectors.json';
  var CACHE_KEY = 'portility_selectors_cache';
  var CACHE_TIMESTAMP_KEY = 'portility_selectors_cached_at';
  var CACHE_TTL = 6 * 60 * 60 * 1000; // 6 hours

  // ─── Hardcoded fallback defaults (current selectors from content scripts) ──
  var DEFAULT_SELECTORS = {
    claude: {
      human: [
        '[data-testid="user-message"]',
        '[data-testid="human-turn"]',
        '[class*="human-turn"]',
        '[class*="HumanTurn"]',
      ],
      ai_class_fragment: 'font-claude-response',
      input: 'div.ProseMirror[contenteditable="true"]',
      send_button: [
        'button[aria-label="Send Message"]',
        'button[aria-label="Send message"]',
        'fieldset button[type="button"]:last-child',
        'button[data-testid="send-button"]',
      ],
      uploadButton: "button[aria-label*='Attach'], button[aria-label*='upload']",
      uploadInput: "input[type='file']",
      artifactContainer: "[data-testid='artifact'], .artifact-panel",
      artifactTitle: "[data-testid='artifact-title'], .artifact-name",
      artifactContent: "[data-testid='artifact-content'], .artifact-body",
    },
    chatgpt: {
      human: '[data-message-author-role="user"]',
      ai: '[data-message-author-role="assistant"]',
      input: '#prompt-textarea',
      send_button: [
        'button[data-testid="send-button"]',
        'button[aria-label="Send prompt"]',
        'button[aria-label="Send"]',
      ],
      uploadButton: "button[aria-label*='attach'], button[aria-label*='upload']",
      uploadInput: "input[type='file']",
      artifactContainer: "[class*='artifact'], .preview-panel",
      artifactTitle: "[class*='artifact-title'], .preview-title",
      artifactContent: "[class*='artifact-content'], .preview-content",
    },
    gemini: {
      human: ['.user-query-text', '[data-turn-role="user"]', '.query-text', 'user-query'],
      ai: ['.model-response-text', '[data-turn-role="model"]', '.response-text', 'model-response'],
      input: '.ql-editor[contenteditable="true"]',
      send_button: [
        'button.send-button',
        'button[aria-label="Send message"]',
        'button[aria-label="Send Message"]',
        '.input-area button[mat-icon-button]',
      ],
      uploadButton: "button[aria-label*='attach'], button[aria-label*='upload']",
      uploadInput: "input[type='file']",
      artifactContainer: ".artifact, [data-artifact]",
      artifactTitle: ".artifact-title, [data-artifact-name]",
      artifactContent: ".artifact-content, [data-artifact-body]",
    },
  };

  /**
   * Fetch selectors from GitHub and cache them.
   * @returns {Promise<Object|null>} selectors object or null on failure
   */
  function fetchAndCache() {
    if (GITHUB_RAW_URL === 'REPLACE_WITH_RAW_GITHUB_URL') {
      return Promise.resolve(null); // Not configured yet
    }

    return fetch(GITHUB_RAW_URL, { cache: 'no-store' })
      .then(function (resp) {
        if (!resp.ok) throw new Error('GitHub fetch failed: ' + resp.status);
        return resp.json();
      })
      .then(function (data) {
        chrome.storage.local.set({
          [CACHE_KEY]: data,
          [CACHE_TIMESTAMP_KEY]: Date.now(),
        });
        return data;
      })
      .catch(function (err) {
        console.warn('[Portility] Selector fetch failed:', err.message);
        return null;
      });
  }

  /**
   * Get selectors from cache or fetch fresh.
   * @returns {Promise<Object>} merged selectors (remote + defaults)
   */
  function getCachedSelectors() {
    return new Promise(function (resolve) {
      chrome.storage.local.get([CACHE_KEY, CACHE_TIMESTAMP_KEY], function (stored) {
        var cachedAt = stored[CACHE_TIMESTAMP_KEY] || 0;
        var isFresh = (Date.now() - cachedAt) < CACHE_TTL;

        if (stored[CACHE_KEY] && isFresh) {
          resolve(mergeWithDefaults(stored[CACHE_KEY]));
        } else {
          fetchAndCache().then(function (data) {
            resolve(data ? mergeWithDefaults(data) : DEFAULT_SELECTORS);
          });
        }
      });
    });
  }

  /**
   * Force refresh — ignores cache, pulls from GitHub immediately.
   * @returns {Promise<{success: boolean, message: string}>}
   */
  function forceRefresh() {
    return fetchAndCache().then(function (data) {
      if (data) {
        window.PortilitySelectors.current = mergeWithDefaults(data);
        return { success: true, message: 'Selectors updated successfully.' };
      }
      return { success: false, message: 'Fetch failed or not configured.' };
    });
  }

  /**
   * Merge remote selectors with defaults — remote values take precedence,
   * defaults fill in any missing keys.
   */
  function mergeWithDefaults(remote) {
    var merged = {};
    for (var platform in DEFAULT_SELECTORS) {
      merged[platform] = Object.assign({}, DEFAULT_SELECTORS[platform], remote[platform] || {});
    }
    return merged;
  }

  // ─── Expose globally ───────────────────────────────────────────────────
  window.PortilitySelectors = {
    get: getCachedSelectors,
    forceRefresh: forceRefresh,
    defaults: DEFAULT_SELECTORS,
    current: DEFAULT_SELECTORS, // Synchronous access; updated async below
  };

  // Async init: try to load cached/remote selectors and update .current
  getCachedSelectors().then(function (selectors) {
    if (selectors) window.PortilitySelectors.current = selectors;
  }).catch(function () { /* keep defaults */ });
})();
