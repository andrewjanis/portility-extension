/**
 * settings.js
 * Portility — Options page logic.
 * Wires up Google Drive connect/disconnect, selector refresh, and logout.
 */
'use strict';

document.addEventListener('DOMContentLoaded', function () {

  // ─── DOM refs ──────────────────────────────────────────────────────────────
  var driveDot = document.getElementById('driveDot');
  var driveStatusText = document.getElementById('driveStatusText');
  var driveConnectBtn = document.getElementById('driveConnectBtn');
  var driveDisconnectBtn = document.getElementById('driveDisconnectBtn');
  var driveFeedback = document.getElementById('driveFeedback');

  var refreshSelectorsBtn = document.getElementById('refreshSelectorsBtn');
  var selectorFeedback = document.getElementById('selectorFeedback');

  var logoutBtn = document.getElementById('logoutBtn');
  var logoutFeedback = document.getElementById('logoutFeedback');

  var versionLabel = document.getElementById('versionLabel');

  // ─── Version label ─────────────────────────────────────────────────────────
  var manifest = chrome.runtime.getManifest();
  if (manifest && manifest.version) {
    versionLabel.textContent = 'v' + manifest.version;
  }

  // ─── Helpers ───────────────────────────────────────────────────────────────
  function showFeedback(el, msg, cls) {
    el.textContent = msg;
    el.className = 'feedback ' + (cls || 'info');
  }

  function clearFeedback(el) {
    el.textContent = '';
    el.className = 'feedback';
  }

  // ─── Google Drive status ───────────────────────────────────────────────────
  function updateDriveUI(connected) {
    if (connected) {
      driveDot.className = 'status-dot connected';
      driveStatusText.textContent = 'Connected';
      driveConnectBtn.style.display = 'none';
      driveDisconnectBtn.style.display = '';
    } else {
      driveDot.className = 'status-dot disconnected';
      driveStatusText.textContent = 'Not connected';
      driveConnectBtn.style.display = '';
      driveDisconnectBtn.style.display = 'none';
    }
  }

  // Check initial state
  GDriveManager.isConnected().then(updateDriveUI);

  // Connect
  driveConnectBtn.addEventListener('click', function () {
    clearFeedback(driveFeedback);
    driveConnectBtn.disabled = true;
    GDriveManager.connect()
      .then(function () {
        updateDriveUI(true);
        showFeedback(driveFeedback, 'Google Drive connected successfully.', 'success');
      })
      .catch(function (err) {
        showFeedback(driveFeedback, 'Connection failed: ' + err.message, 'error');
      })
      .then(function () {
        driveConnectBtn.disabled = false;
      });
  });

  // Disconnect
  driveDisconnectBtn.addEventListener('click', function () {
    clearFeedback(driveFeedback);
    driveDisconnectBtn.disabled = true;
    GDriveManager.disconnect()
      .then(function () {
        updateDriveUI(false);
        showFeedback(driveFeedback, 'Google Drive disconnected.', 'info');
      })
      .catch(function (err) {
        showFeedback(driveFeedback, 'Disconnect failed: ' + err.message, 'error');
      })
      .then(function () {
        driveDisconnectBtn.disabled = false;
      });
  });

  // ─── Selector refresh ─────────────────────────────────────────────────────
  refreshSelectorsBtn.addEventListener('click', function () {
    clearFeedback(selectorFeedback);
    refreshSelectorsBtn.disabled = true;

    // Clear the cache first
    chrome.storage.local.remove(
      ['portility_selectors_cache', 'portility_selectors_cached_at'],
      function () {
        showFeedback(selectorFeedback, 'Selector cache cleared. Fresh selectors will load on next page visit.', 'success');
        refreshSelectorsBtn.disabled = false;
      }
    );
  });

  // ─── Logout ────────────────────────────────────────────────────────────────
  logoutBtn.addEventListener('click', function () {
    clearFeedback(logoutFeedback);
    logoutBtn.disabled = true;

    // Disconnect Drive if connected, then clear extension data
    GDriveManager.isConnected()
      .then(function (connected) {
        if (connected) return GDriveManager.disconnect();
      })
      .then(function () {
        return new Promise(function (resolve) {
          chrome.storage.local.clear(resolve);
        });
      })
      .then(function () {
        showFeedback(logoutFeedback, 'Logged out. All local data cleared.', 'success');
        updateDriveUI(false);
      })
      .catch(function (err) {
        showFeedback(logoutFeedback, 'Logout error: ' + err.message, 'error');
      })
      .then(function () {
        logoutBtn.disabled = false;
      });
  });
});
