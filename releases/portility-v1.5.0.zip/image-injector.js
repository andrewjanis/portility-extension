/**
 * image-injector.js
 * Portility — MAIN world content script for image injection.
 *
 * Runs in the page's main JavaScript context (not the isolated content script world)
 * so that File/DataTransfer/ClipboardEvent objects are from the same context as the
 * page's event handlers. This is required because Chrome isolates content script
 * JS objects from page JS objects — paste events dispatched from the isolated world
 * have empty clipboardData when read by the page's handlers.
 *
 * Communication: receives images via window.postMessage from the isolated-world
 * content script (content-shared.js).
 */
(function () {
  'use strict';

  window.addEventListener('message', function (event) {
    if (event.source !== window) return;
    if (!event.data || event.data.type !== 'PORTILITY_INJECT_IMAGES') return;

    var images = event.data.images;
    if (!images || images.length === 0) return;

    console.log('[Portility:main] Received ' + images.length + ' image(s) to inject');

    // Poll for chat input (it should already exist since the isolated-world script waited)
    var attempts = 0;
    var interval = setInterval(function () {
      var input = findChatInput();
      if (input) {
        clearInterval(interval);
        pasteImagesSequentially(input, images, 0);
      }
      if (++attempts > 30) {
        clearInterval(interval);
        console.warn('[Portility:main] Chat input not found for image injection');
      }
    }, 200);
  });

  function findChatInput() {
    return document.querySelector('div.ProseMirror[contenteditable="true"]')  // Claude
      || document.querySelector('#prompt-textarea')                           // ChatGPT
      || document.querySelector('.ql-editor[contenteditable="true"]')         // Gemini
      || document.querySelector('rich-textarea div[contenteditable="true"]')  // Gemini alt
      || document.querySelector('div[contenteditable="true"]')                // generic
      || document.querySelector('textarea');                                  // fallback
  }

  function base64ToFile(imageData) {
    var byteString = atob(imageData.base64Data);
    var ab = new ArrayBuffer(byteString.length);
    var ia = new Uint8Array(ab);
    for (var i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    var blob = new Blob([ab], { type: imageData.mimeType || 'image/png' });
    return new File([blob], imageData.filename || 'image.png', {
      type: imageData.mimeType || 'image/png',
      lastModified: Date.now(),
    });
  }

  /**
   * Dispatch a synthetic paste event with an image file.
   * Because this runs in the MAIN world, all objects (File, DataTransfer, etc.)
   * are from the same context as the page's event handlers.
   */
  function dispatchImagePaste(input, file) {
    var dt = new DataTransfer();
    dt.items.add(file);

    // Strategy 1: ClipboardEvent with clipboardData getter override
    try {
      var pasteEvent = new ClipboardEvent('paste', {
        bubbles: true,
        cancelable: true,
      });
      Object.defineProperty(pasteEvent, 'clipboardData', {
        get: function () { return dt; },
      });
      input.focus();
      var prevented = !input.dispatchEvent(pasteEvent);
      if (prevented) {
        console.log('[Portility:main] Image handled via ClipboardEvent override');
        return true;
      }
    } catch (e) {
      console.warn('[Portility:main] ClipboardEvent strategy error:', e.message);
    }

    // Strategy 2: Plain Event('paste') with clipboardData value
    try {
      var plainPaste = new Event('paste', { bubbles: true, cancelable: true });
      Object.defineProperty(plainPaste, 'clipboardData', {
        value: dt,
      });
      input.focus();
      var prevented2 = !input.dispatchEvent(plainPaste);
      if (prevented2) {
        console.log('[Portility:main] Image handled via plain Event paste');
        return true;
      }
    } catch (e2) {
      console.warn('[Portility:main] Plain paste strategy error:', e2.message);
    }

    // Strategy 3: DragEvent drop
    try {
      var dt2 = new DataTransfer();
      dt2.items.add(file);
      var dropEvent = new DragEvent('drop', {
        bubbles: true,
        cancelable: true,
        dataTransfer: dt2,
      });
      input.focus();
      var prevented3 = !input.dispatchEvent(dropEvent);
      if (prevented3) {
        console.log('[Portility:main] Image handled via drop event');
        return true;
      }
    } catch (e3) {
      console.warn('[Portility:main] Drop strategy error:', e3.message);
    }

    return false;
  }

  function pasteImagesSequentially(input, images, index) {
    if (index >= images.length) {
      console.log('[Portility:main] Finished injecting ' + images.length + ' image(s)');
      window.postMessage({ type: 'PORTILITY_IMAGES_DONE', count: images.length }, '*');
      return;
    }

    var imageData = images[index];
    try {
      var file = base64ToFile(imageData);
      var handled = dispatchImagePaste(input, file);
      console.log('[Portility:main] Image ' + (index + 1) + '/' + images.length +
        ' (' + imageData.filename + ') handled=' + handled);
    } catch (e) {
      console.warn('[Portility:main] Failed: ' + imageData.filename + ': ' + e.message);
    }

    // Delay between images to let the editor process each one
    if (index + 1 < images.length) {
      setTimeout(function () {
        pasteImagesSequentially(input, images, index + 1);
      }, 500);
    } else {
      window.postMessage({ type: 'PORTILITY_IMAGES_DONE', count: images.length }, '*');
    }
  }
})();
