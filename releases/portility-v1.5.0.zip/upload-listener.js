/**
 * upload-listener.js
 * Portility — Real-time upload detection via MutationObserver.
 * Watches for file uploads (images, file chips, input[type=file] changes).
 * Sends ARTIFACT_DETECTED message to background.js.
 * Loaded AFTER platform-specific content scripts.
 */
(function () {
  'use strict';

  // ─── Platform detection ─────────────────────────────────────────────────
  function getPlatform() {
    var host = window.location.hostname;
    if (host.indexOf('claude.ai') !== -1) return 'claude';
    if (host.indexOf('chatgpt.com') !== -1) return 'chatgpt';
    if (host.indexOf('gemini.google.com') !== -1) return 'gemini';
    return null;
  }

  var platform = getPlatform();
  if (!platform) return;

  // ─── Debounce helper ────────────────────────────────────────────────────
  function debounce(fn, ms) {
    var timer = null;
    return function () {
      var args = arguments;
      var ctx = this;
      clearTimeout(timer);
      timer = setTimeout(function () { fn.apply(ctx, args); }, ms);
    };
  }

  // ─── Duplicate tracking ─────────────────────────────────────────────────
  var detectedUploads = new Map();

  function isDuplicate(key) {
    if (detectedUploads.has(key)) return true;
    detectedUploads.set(key, Date.now());
    // Prune entries older than 5 minutes
    var cutoff = Date.now() - 5 * 60 * 1000;
    detectedUploads.forEach(function (ts, k) {
      if (ts < cutoff) detectedUploads.delete(k);
    });
    return false;
  }

  // ─── Upload indicator selectors per platform ────────────────────────────
  var UPLOAD_SELECTORS = {
    claude: [
      "img[src*='blob:']",
      "[data-testid*='file']",
      "[class*='file-chip']",
      "[class*='attachment']",
    ],
    chatgpt: [
      "img[src*='blob:']",
      "[data-testid*='file']",
      "[class*='attachment']",
    ],
    gemini: [
      "img[src*='blob:']",
      "[class*='attachment']",
    ],
  };

  var selectors = UPLOAD_SELECTORS[platform] || [];

  // ─── Send artifact to background ───────────────────────────────────────
  function sendArtifact(filename, extra) {
    var payload = {
      type: 'ARTIFACT_DETECTED',
      platform: platform,
      filename: filename,
      detectedAt: Date.now(),
    };
    if (extra) {
      if (extra.fileSize) payload.fileSize = extra.fileSize;
      if (extra.fileType) payload.fileType = extra.fileType;
    }
    chrome.runtime.sendMessage(payload, function () {
      void chrome.runtime.lastError;
    });
  }

  // ─── MutationObserver callback ──────────────────────────────────────────
  function checkForUploads(mutations) {
    for (var m = 0; m < mutations.length; m++) {
      var addedNodes = mutations[m].addedNodes;
      for (var n = 0; n < addedNodes.length; n++) {
        var node = addedNodes[n];
        if (node.nodeType !== Node.ELEMENT_NODE) continue;

        for (var s = 0; s < selectors.length; s++) {
          // Check the node itself and its descendants
          var matches = [];
          if (node.matches && node.matches(selectors[s])) matches.push(node);
          if (node.querySelectorAll) {
            var found = node.querySelectorAll(selectors[s]);
            for (var f = 0; f < found.length; f++) matches.push(found[f]);
          }

          for (var i = 0; i < matches.length; i++) {
            var el = matches[i];
            var filename = el.alt || el.getAttribute('data-testid') ||
              (el.textContent ? el.textContent.trim().substring(0, 80) : '') ||
              'upload-' + Date.now();
            var src = el.src || el.getAttribute('href') || '';
            var key = platform + '|' + filename + '|' + src.substring(0, 100);

            if (!isDuplicate(key)) {
              console.log('[Portility] Upload detected:', filename);
              sendArtifact(filename);
            }
          }
        }
      }
    }
  }

  var debouncedCheck = debounce(checkForUploads, 200);

  // ─── Start observer ─────────────────────────────────────────────────────
  var observer = new MutationObserver(function (mutations) {
    debouncedCheck(mutations);
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
  });

  // ─── File input change listener ─────────────────────────────────────────
  document.addEventListener('change', function (e) {
    if (!e.target || e.target.type !== 'file' || !e.target.files) return;
    for (var i = 0; i < e.target.files.length; i++) {
      var file = e.target.files[i];
      var key = 'file-input|' + file.name + '|' + file.size;
      if (!isDuplicate(key)) {
        console.log('[Portility] File input detected:', file.name);
        sendArtifact(file.name, { fileSize: file.size, fileType: file.type });
      }
    }
  }, true);

  console.log('[Portility] Upload listener active on ' + platform);
})();
