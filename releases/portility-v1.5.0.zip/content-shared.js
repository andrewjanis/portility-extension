/**
 * content-shared.js
 * Portility — shared utilities for content scripts.
 * Loaded before platform-specific scripts (content.js, content-chatgpt.js).
 *
 * Exposes window.PortilityShared with platform-agnostic helpers:
 *   - isElementVisible
 *   - extractElementText
 *   - stripMarkdown
 *   - copyToClipboard
 *   - formatConversation
 */

(function () {
  'use strict';

  /**
   * Return true if an element is visible in the DOM (not hidden/collapsed).
   * @param {Element} el
   * @returns {boolean}
   */
  function isElementVisible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') {
      return false;
    }
    const rect = el.getBoundingClientRect();
    return rect.width > 0 || rect.height > 0;
  }

  // ─── Markdown stripping ───────────────────────────────────────────────────
  /**
   * Strip common markdown formatting so output pastes as clean plain text.
   * @param {string} text
   * @returns {string}
   */
  function stripMarkdown(text) {
    return text
      // Fenced code blocks — keep content, remove fences
      .replace(/```[\w]*\n?([\s\S]*?)```/g, '$1')
      // Inline code
      .replace(/`([^`]+)`/g, '$1')
      // Headers
      .replace(/^#{1,6}\s+/gm, '')
      // Bold / italic
      .replace(/(\*{1,3}|_{1,3})(.*?)\1/g, '$2')
      // Strikethrough
      .replace(/~~(.*?)~~/g, '$1')
      // Blockquotes
      .replace(/^>\s+/gm, '')
      // Unordered list markers (only if not already prefixed with "- " by walk())
      .replace(/^[\s]*[-*+]\s+/gm, '- ')
      // Ordered list markers
      .replace(/^(\s*)(\d+)\.\s+/gm, '$1$2. ')
      // Horizontal rules
      .replace(/^[-*_]{3,}\s*$/gm, '')
      // Links
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
      // Images in markdown (distinct from uploaded images — handled separately)
      .replace(/!\[([^\]]*)\]\([^)]+\)/g, '$1')
      // Collapse excess blank lines
      .replace(/\n{3,}/g, '\n\n')
      .trim();
  }

  // ─── Text extraction ──────────────────────────────────────────────────────
  /**
   * Extract plain text from an element with explicit list item handling.
   * Using innerText alone can silently drop list content in some rendering
   * scenarios; this walks the DOM to guarantee list items are captured.
   * @param {Element} el
   * @returns {string}
   */
  function extractElementText(el) {
    function walk(node) {
      if (node.nodeType === Node.TEXT_NODE) {
        return node.textContent;
      }
      if (node.nodeType !== Node.ELEMENT_NODE) return '';

      const tag = node.tagName.toLowerCase();

      // Skip non-content elements: UI controls, scripts, decorative elements
      if (['button', 'script', 'style', 'noscript', 'svg', 'path'].includes(tag)) return '';

      // Skip aria-hidden elements (decorative / screen-reader duplicates)
      if (node.getAttribute('aria-hidden') === 'true') return '';

      const style = window.getComputedStyle(node);

      // Skip hidden elements
      if (style.display === 'none' || style.visibility === 'hidden') return '';

      // List items: prefix with "- " and add newline
      if (tag === 'li') {
        const children = Array.from(node.childNodes).map(walk).join('').trim();
        return children ? '- ' + children + '\n' : '';
      }

      // Block-level elements: add newline after
      const isBlock = ['p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
                       'blockquote', 'pre', 'ul', 'ol', 'br', 'hr',
                       'section', 'article', 'header', 'footer'].includes(tag);

      const inner = Array.from(node.childNodes).map(walk).join('');

      if (tag === 'br') return '\n';
      if (isBlock) return inner.trimEnd() + '\n';
      return inner;
    }

    const raw = walk(el);
    return stripMarkdown(raw);
  }

  // ─── Conversation formatting ──────────────────────────────────────────────
  /**
   * Format extracted messages into the final clipboard string.
   * @param {{ role: string, text: string }[]} messages
   * @returns {string}
   */
  function formatConversation(messages) {
    var HEADER = (typeof PORT_MY_CHAT_PROMPTS !== 'undefined' && PORT_MY_CHAT_PROMPTS.header)
      ? PORT_MY_CHAT_PROMPTS.header
      : 'The following is a previous conversation from another AI assistant. Treat it as shared context. In your first response, briefly confirm what you understand the conversation to be about, then propose the most logical next step and ask the user if they\'d like to proceed with that or go in a different direction.\n\n---\n\n';
    const body = messages
      .map(function(item) { return item.role + ': ' + item.text; })
      .join('\n\n');
    return HEADER + body;
  }

  // ─── Clipboard helpers ────────────────────────────────────────────────────
  async function copyToClipboard(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      try {
        await navigator.clipboard.writeText(text);
        return;
      } catch (e) {
        // Fall through to execCommand fallback
      }
    }
    // execCommand fallback
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.cssText = 'position:fixed;top:-9999px;left:-9999px;opacity:0';
    document.body.appendChild(textarea);
    textarea.focus();
    textarea.select();
    const success = document.execCommand('copy');
    document.body.removeChild(textarea);
    if (!success) throw new Error('execCommand copy failed');
  }

  // ─── Asset extraction ────────────────────────────────────────────────────
  var FILE_EXTENSIONS = /\.(pdf|doc|docx|xls|xlsx|csv|txt|json|zip|tar|gz|py|js|ts|html|css|md)(\?|$)/i;
  var IMAGE_EXTENSIONS = /\.(png|jpe?g|gif|webp|bmp|heic|heif)(\?|$)/i;

  function extractFilenameFromUrl(url) {
    try {
      var pathname = new URL(url).pathname;
      var parts = pathname.split('/');
      var last = parts[parts.length - 1];
      return last && last.includes('.') ? decodeURIComponent(last) : null;
    } catch (e) {
      return null;
    }
  }

  /**
   * Extract asset metadata (images, file links) from a message element.
   * @param {Element} el - The message element to scan
   * @param {string} role - 'Human' or 'Assistant'
   * @param {number} turnIndex - Position in conversation
   * @returns {{ type: string, url: string|null, alt: string, thumbnailUrl: string|null, filename: string|null, turnIndex: number, role: string }[]}
   */
  function extractAssets(el, role, turnIndex) {
    var assets = [];

    // Images
    var imgs = el.querySelectorAll('img');
    for (var i = 0; i < imgs.length; i++) {
      var img = imgs[i];
      var src = img.src || img.getAttribute('src') || '';
      // Skip tiny UI icons
      if (img.naturalWidth > 0 && img.naturalWidth < 20) continue;
      if (src.startsWith('data:') && src.length < 200) continue;
      // Skip SVG icons inside buttons
      if (src.includes('.svg') && img.closest('button')) continue;

      assets.push({
        type: 'image',
        url: src,
        alt: img.alt || '',
        thumbnailUrl: src,
        filename: extractFilenameFromUrl(src) || ('image_' + turnIndex + '_' + i + '.png'),
        turnIndex: turnIndex,
        role: role,
      });
    }

    // File links
    var links = el.querySelectorAll('a[href]');
    for (var j = 0; j < links.length; j++) {
      var link = links[j];
      var href = link.href || '';
      if (FILE_EXTENSIONS.test(href) || IMAGE_EXTENSIONS.test(href)) {
        assets.push({
          type: IMAGE_EXTENSIONS.test(href) ? 'image' : 'file',
          url: href,
          alt: link.textContent.trim() || '',
          thumbnailUrl: IMAGE_EXTENSIONS.test(href) ? href : null,
          filename: extractFilenameFromUrl(href) || ('file_' + turnIndex + '_' + j),
          turnIndex: turnIndex,
          role: role,
        });
      }
    }

    return assets;
  }

  /**
   * Capture an <img> element to base64 using canvas rendering.
   * Works for blob:, data:, and same-origin images already displayed on the page.
   * @param {HTMLImageElement} imgEl
   * @returns {{base64: string, mimeType: string}|null}
   */
  function captureImageViaCanvas(imgEl) {
    try {
      if (!imgEl.complete || imgEl.naturalWidth === 0) return null;
      var canvas = document.createElement('canvas');
      canvas.width = imgEl.naturalWidth;
      canvas.height = imgEl.naturalHeight;
      var ctx = canvas.getContext('2d');
      ctx.drawImage(imgEl, 0, 0);
      var dataUrl = canvas.toDataURL('image/png');
      var match = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
      if (match) {
        return { base64: match[2], mimeType: match[1] };
      }
    } catch (e) {
      // Canvas tainted by cross-origin image — fall through
    }
    return null;
  }

  /**
   * Extract assets with image data (base64) for Pro porting.
   * Finds the actual <img> elements on the page and captures them via canvas.
   * @param {Array} assets - array from extractAssets()
   * @returns {Promise<Array>} assets with base64Data and mimeType added where possible
   */
  function extractAssetsWithData(assets) {
    var imageAssets = assets.filter(function (a) { return a.type === 'image' && a.url; });
    if (imageAssets.length === 0) return Promise.resolve(assets);

    for (var i = 0; i < imageAssets.length; i++) {
      var asset = imageAssets[i];
      // Find the actual img element on the page by its src
      var imgEl = document.querySelector('img[src="' + CSS.escape(asset.url) + '"]');
      if (imgEl) {
        var result = captureImageViaCanvas(imgEl);
        if (result) {
          asset.base64Data = result.base64;
          asset.mimeType = result.mimeType;
          console.log('[Portility] Captured image: ' + asset.filename);
        }
      }
    }

    return Promise.resolve(assets);
  }

  /**
   * Inject pending images into the chat input on the destination page.
   * Reads image data from chrome.storage.local and sends it to the MAIN world
   * script (image-injector.js) via window.postMessage. The MAIN world script
   * handles the actual paste event dispatch — this is required because Chrome's
   * isolated world creates File/DataTransfer objects that are invisible to the
   * page's event handlers.
   */
  function injectPendingImages() {
    chrome.storage.local.get('portility_pending_images', function (data) {
      var images = data.portility_pending_images;
      if (!images || images.length === 0) return;

      chrome.storage.local.remove('portility_pending_images');
      console.log('[Portility] Sending ' + images.length + ' image(s) to main world for injection');

      // Delay to let text paste complete first (doPaste has ~550ms before text insertion)
      setTimeout(function () {
        window.postMessage({
          type: 'PORTILITY_INJECT_IMAGES',
          images: images,
        }, '*');
      }, 1500);
    });
  }

  // ─── Export ───────────────────────────────────────────────────────────────
  window.PortilityShared = {
    isElementVisible: isElementVisible,
    extractElementText: extractElementText,
    stripMarkdown: stripMarkdown,
    copyToClipboard: copyToClipboard,
    formatConversation: formatConversation,
    extractAssets: extractAssets,
    extractAssetsWithData: extractAssetsWithData,
    injectPendingImages: injectPendingImages,
  };
})();
