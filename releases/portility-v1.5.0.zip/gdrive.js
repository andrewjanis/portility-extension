/**
 * gdrive.js
 * Portility — Google Drive integration using chrome.identity.getAuthToken().
 * Manages file uploads to a "PortMyChat-Temp" folder in user's Google Drive.
 *
 * Uses the manifest oauth2 config with drive.file scope.
 * No Client Secret needed. Chrome handles token management.
 */
'use strict';

var GDriveManager = {

  FOLDER_NAME: 'PortMyChat-Temp',

  /**
   * Get an OAuth token via chrome.identity.getAuthToken().
   * @param {boolean} interactive — show consent UI if needed
   * @returns {Promise<string>} access token
   */
  getToken: function (interactive) {
    return new Promise(function (resolve, reject) {
      chrome.identity.getAuthToken({ interactive: !!interactive }, function (token) {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(token);
        }
      });
    });
  },

  /**
   * Remove a cached token (for disconnect or forced refresh).
   * @param {string} token
   * @returns {Promise<void>}
   */
  revokeToken: function (token) {
    return new Promise(function (resolve) {
      chrome.identity.removeCachedAuthToken({ token: token }, resolve);
    });
  },

  /**
   * Connect to Google Drive (first-time consent).
   * @returns {Promise<string>} access token
   */
  connect: function () {
    var self = this;
    return self.getToken(true).then(function (token) {
      return new Promise(function (resolve) {
        chrome.storage.local.set({ gdrive_connected: true }, function () {
          resolve(token);
        });
      });
    });
  },

  /**
   * Disconnect from Google Drive — revoke token and clear stored state.
   * @returns {Promise<void>}
   */
  disconnect: function () {
    var self = this;
    return self.getToken(false)
      .then(function (token) {
        if (token) {
          return self.revokeToken(token).then(function () {
            // Best-effort revoke on Google's side
            return fetch('https://accounts.google.com/o/oauth2/revoke?token=' + token)
              .catch(function () {});
          });
        }
      })
      .catch(function () { /* ignore errors during disconnect */ })
      .then(function () {
        return new Promise(function (resolve) {
          chrome.storage.local.remove(['gdrive_connected', 'gdrive_folder_id'], resolve);
        });
      });
  },

  /**
   * Check if user has connected Google Drive.
   * @returns {Promise<boolean>}
   */
  isConnected: function () {
    return new Promise(function (resolve) {
      chrome.storage.local.get('gdrive_connected', function (data) {
        resolve(data.gdrive_connected === true);
      });
    });
  },

  /**
   * Get or create the PortMyChat-Temp folder in the user's Drive.
   * @returns {Promise<string>} folder ID
   */
  getOrCreateFolder: function () {
    var self = this;
    return new Promise(function (resolve) {
      chrome.storage.local.get('gdrive_folder_id', function (data) {
        resolve(data.gdrive_folder_id || null);
      });
    }).then(function (cached) {
      if (cached) return cached;

      return self.getToken(false).then(function (token) {
        // Search for existing folder
        var q = encodeURIComponent(
          "name='" + self.FOLDER_NAME + "' and mimeType='application/vnd.google-apps.folder' and trashed=false"
        );
        return fetch('https://www.googleapis.com/drive/v3/files?q=' + q + '&fields=files(id,name)', {
          headers: { 'Authorization': 'Bearer ' + token },
        })
        .then(function (resp) { return resp.json(); })
        .then(function (data) {
          if (data.files && data.files.length > 0) {
            return data.files[0].id;
          }
          // Create folder
          return fetch('https://www.googleapis.com/drive/v3/files', {
            method: 'POST',
            headers: {
              'Authorization': 'Bearer ' + token,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              name: self.FOLDER_NAME,
              mimeType: 'application/vnd.google-apps.folder',
            }),
          })
          .then(function (resp) { return resp.json(); })
          .then(function (folder) { return folder.id; });
        })
        .then(function (folderId) {
          return new Promise(function (resolve) {
            chrome.storage.local.set({ gdrive_folder_id: folderId }, function () {
              resolve(folderId);
            });
          });
        });
      });
    });
  },

  /**
   * Upload a file to the PortMyChat-Temp folder.
   * @param {string} filename
   * @param {string|Blob} content
   * @param {string} mimeType
   * @returns {Promise<{id: string, name: string, webViewLink: string}>}
   */
  uploadFile: function (filename, content, mimeType) {
    var self = this;
    return Promise.all([
      self.getToken(false),
      self.getOrCreateFolder(),
    ]).then(function (results) {
      var token = results[0];
      var folderId = results[1];

      var metadata = { name: filename, parents: [folderId] };
      var fileBlob = content instanceof Blob
        ? content
        : new Blob([content], { type: mimeType || 'application/octet-stream' });

      var form = new FormData();
      form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
      form.append('file', fileBlob);

      return fetch(
        'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink',
        {
          method: 'POST',
          headers: { 'Authorization': 'Bearer ' + token },
          body: form,
        }
      );
    }).then(function (resp) {
      if (!resp.ok) throw new Error('Drive upload failed: ' + resp.status);
      return resp.json();
    });
  },

  /**
   * Make a file shareable (anyone with link can view).
   * @param {string} fileId
   * @returns {Promise<void>}
   */
  shareFile: function (fileId) {
    return this.getToken(false).then(function (token) {
      return fetch('https://www.googleapis.com/drive/v3/files/' + fileId + '/permissions', {
        method: 'POST',
        headers: {
          'Authorization': 'Bearer ' + token,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ role: 'reader', type: 'anyone' }),
      });
    });
  },

  /**
   * Delete a file from Google Drive.
   * @param {string} fileId
   * @returns {Promise<void>}
   */
  deleteFile: function (fileId) {
    if (!fileId) return Promise.resolve();
    return this.getToken(false).then(function (token) {
      return fetch('https://www.googleapis.com/drive/v3/files/' + fileId, {
        method: 'DELETE',
        headers: { 'Authorization': 'Bearer ' + token },
      });
    }).then(function (resp) {
      if (!resp.ok && resp.status !== 404) {
        throw new Error('Drive delete failed: ' + resp.status);
      }
    }).catch(function (err) {
      console.warn('[Portility] Drive delete error:', err.message);
    });
  },
};
