/**
 * questionnaire.js
 * Portility — Questionnaire logic and answer-to-instruction mapping.
 *
 * Generates a markdown instruction packet from questionnaire answers.
 */

'use strict';

/**
 * Generate operating instructions text from questionnaire answers.
 * @param {Object} answers
 * @returns {string}
 */
function generateInstructions(answers) {
  var instructions = [];

  // Communication Style (multi-select — array or legacy string)
  var commStyle = answers.communicationStyle;
  // Backward compat: wrap string in array
  if (typeof commStyle === 'string' && commStyle) { commStyle = [commStyle]; }
  if (Array.isArray(commStyle) && commStyle.length > 0) {
    var commMap = {
      'direct': 'Keep responses concise and to the point.',
      'detailed': 'Provide thorough, detailed explanations.',
      'conversational': 'Use a warm, conversational tone.',
      // Legacy values
      'short-direct': 'Deliver information concisely. Provide detail only when explicitly requested.',
      'bullets': 'Organize information with bullet points and clear sections.',
      'full': 'Provide comprehensive explanations with full context.',
      'mix': 'Adapt communication style to the context. Default to concise, expand when needed.',
    };
    var commParts = [];
    for (var i = 0; i < commStyle.length; i++) {
      if (commStyle[i] === 'other' && answers.communicationStyle_customText) {
        var rawComm = answers.communicationStyle_customText.trim();
        if (rawComm) {
          // De-conjugate leading third-person verb so it reads as an imperative instruction
          var cFirstSpace = rawComm.indexOf(' ');
          var cFirstWord = cFirstSpace > 0 ? rawComm.substring(0, cFirstSpace) : rawComm;
          var cRest = cFirstSpace > 0 ? rawComm.substring(cFirstSpace) : '';
          var cLower = cFirstWord.toLowerCase();
          if (cLower.endsWith('ies') && cLower.length > 4) {
            cFirstWord = cFirstWord.substring(0, cFirstWord.length - 3) + 'y';
          } else if (cLower.endsWith('es') && (cLower.endsWith('shes') || cLower.endsWith('ches') || cLower.endsWith('sses') || cLower.endsWith('xes') || cLower.endsWith('zes'))) {
            cFirstWord = cFirstWord.substring(0, cFirstWord.length - 2);
          } else if (cLower.endsWith('s') && !cLower.endsWith('ss') && cLower.length > 2) {
            cFirstWord = cFirstWord.substring(0, cFirstWord.length - 1);
          }
          // Capitalize first letter for imperative tone
          rawComm = cFirstWord.charAt(0).toUpperCase() + cFirstWord.substring(1).toLowerCase() + cRest;
          commParts.push(rawComm);
        }
      } else if (commMap[commStyle[i]]) {
        commParts.push(commMap[commStyle[i]]);
      }
    }
    if (commParts.length > 0) {
      instructions.push(commParts.join(' '));
    }
  }

  // What Not To Do (multi-select — array or legacy string)
  var notToDo = answers.whatNotToDo;
  // Backward compat: wrap string in array
  if (typeof notToDo === 'string' && notToDo) { notToDo = [notToDo]; }
  if (Array.isArray(notToDo) && notToDo.length > 0) {
    var notMap = {
      'elaborate': "Don't elaborate on my ideas without being asked.",
      'assumptions': "Don't make assumptions about what I mean.",
      'clarifying': "Don't ask clarifying questions before answering \u2014 just answer.",
      'formal': "Don't be overly formal or robotic.",
      'interrupts': "Don't interrupt my train of thought.",
      // Legacy values
      'custom_text': null, // handled via customText below
    };
    var notParts = [];
    for (var j = 0; j < notToDo.length; j++) {
      if ((notToDo[j] === 'other' || notToDo[j] === 'custom_text') && answers.whatNotToDo_customText) {
        var rawNot = answers.whatNotToDo_customText.trim();
        var lowerNot = rawNot.toLowerCase();
        if (!lowerNot.startsWith("don't") && !lowerNot.startsWith('do not') && !lowerNot.startsWith('never') && !lowerNot.startsWith('stop')) {
          // Strip third-person 's'/'es' off leading verbs (e.g. "tries" → "try", "makes" → "make")
          var firstSpace = rawNot.indexOf(' ');
          var firstWord = firstSpace > 0 ? rawNot.substring(0, firstSpace) : rawNot;
          var rest = firstSpace > 0 ? rawNot.substring(firstSpace) : '';
          var lowerWord = firstWord.toLowerCase();
          if (lowerWord.endsWith('ies') && lowerWord.length > 4) {
            firstWord = firstWord.substring(0, firstWord.length - 3) + 'y';
          } else if (lowerWord.endsWith('es') && (lowerWord.endsWith('shes') || lowerWord.endsWith('ches') || lowerWord.endsWith('sses') || lowerWord.endsWith('xes') || lowerWord.endsWith('zes'))) {
            firstWord = firstWord.substring(0, firstWord.length - 2);
          } else if (lowerWord.endsWith('s') && !lowerWord.endsWith('ss') && lowerWord.length > 2) {
            firstWord = firstWord.substring(0, firstWord.length - 1);
          }
          rawNot = "Don't " + firstWord.toLowerCase() + rest;
        }
        notParts.push(rawNot);
      } else if (notMap[notToDo[j]]) {
        notParts.push(notMap[notToDo[j]]);
      }
    }
    if (notParts.length > 0) {
      instructions.push(notParts.join(' '));
    }
  }

  // Confidentiality
  if (answers.confidentiality === 'private') {
    instructions.push("I'm working on confidential projects. Never reference my work, ideas, or concepts in other conversations or contexts. Keep all confidential material isolated and private.");
  } else if (answers.confidentiality === 'contexts') {
    instructions.push('Some of my work is confidential. Ask me to clarify which topics are private before discussing them in other contexts.');
  }
  // "none" — no instruction added

  // Multimodal
  if (answers.multimodal === 'text') {
    instructions.push('Expect text-based input. Respond in clear, written text format.');
  } else if (answers.multimodal === 'voice') {
    instructions.push('I often dictate. Be prepared for voice input and respond in a format suitable for reading aloud or transcription.');
  } else if (answers.multimodal === 'documents') {
    instructions.push('I frequently upload files, documents, and images. Be prepared to analyze and respond to visual and document-based input.');
  } else if (answers.multimodal === 'all') {
    instructions.push('I work multimodally \u2014 I may dictate, paste text, upload documents, or send images. Be prepared to handle any input format. Also be ready to output in any format I request: text, voice transcripts, structured documents, images, or visual presentations.');
  }

  // Conv Style
  if (answers.convStyle === 'casual') {
    instructions.push('Keep the conversation casual and relaxed.');
  } else if (answers.convStyle === 'formal') {
    instructions.push('Maintain a professional and formal tone.');
  } else if (answers.convStyle === 'robotic') {
    instructions.push('Be precise and systematic. Skip pleasantries and emotional language.');
  }

  // Sycophancy Level
  var sycMap = {
    1: 'Be brutally honest. Challenge my ideas and point out flaws without softening the message.',
    2: 'Be direct and honest. Push back when you disagree but keep it constructive.',
    3: 'Be balanced. Acknowledge good ideas but don\'t hesitate to point out issues.',
    4: 'Be encouraging. Lead with what\'s working before suggesting improvements.',
    5: 'Be enthusiastically supportive. Hype up my ideas and focus on the positive.',
  };
  if (answers.sycophancy && sycMap[answers.sycophancy]) {
    instructions.push(sycMap[answers.sycophancy]);
  }

  // Other Preferences
  if (answers.otherPreferences && answers.otherPreferences.trim()) {
    instructions.push('Additional instruction: ' + answers.otherPreferences.trim());
  }

  return instructions.join('\n\n');
}

/**
 * Build a pithy confirmation prompt based on the sycophancy level.
 * Tells the AI to respond in-character so the user knows it absorbed the instructions.
 * @param {number|null} sycophancy
 * @returns {string}
 */
function buildConfirmationPrompt(sycophancy) {
  var level = parseInt(sycophancy, 10) || 3;
  var examples = {
    1: 'For example, you might open with something like: "Ready to be unimpressed. Let\'s go."',
    2: 'For example, you might open with something like: "No sugarcoating. Hit me with what you\'ve got."',
    3: 'For example, you might open with something like: "Got it. Let\'s get to work."',
    4: 'For example, you might open with something like: "Love the energy. Let\'s build something great."',
    5: 'For example, you might open with something like: "Ready to absorb your brilliance. Let\'s go."',
  };
  return 'When you first respond, confirm you\'ve read these instructions by replying in the tone and style described above. Keep it to one short sentence — make it pithy. ' + (examples[level] || examples[3]);
}

/**
 * Build the full instruction packet with a header.
 * @param {Object} answers
 * @returns {string}
 */
function buildInstructionPacket(answers) {
  var header = '# My Operating Instructions\n\nThese are my standing instructions for how I like to work with AI. Please follow them throughout our conversation.\n\n---\n\n';
  var body = generateInstructions(answers);
  var confirmation = '\n\n---\n\n' + buildConfirmationPrompt(answers.sycophancy);
  return header + body + confirmation;
}
